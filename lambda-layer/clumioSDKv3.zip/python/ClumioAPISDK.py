# Copyright 2024, Clumio Inc.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#    http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import requests
import json
import boto3
from datetime import datetime, timedelta, timezone
import re
from botocore.exceptions import ClientError
import urllib.parse

apiDICT = {
    "001": {"name": "EC2BackupList", "api": "backups/aws/ec2-instances",
            "header": "application/api.clumio.backup-aws-ebs-volumes=v2+json", "version": "v2",
            "desc": "List EC2 instance backups", "type": "get", "success": 200, "queryParms": {"limit": 100, "start": 1,
                                                                                               "filter": {
                                                                                                   "start_timestamp": [
                                                                                                       "$lte", "$gt"],
                                                                                                   "instance_id": [
                                                                                                       "$eq"]},
                                                                                               "sort": [
                                                                                                   "-start_timestamp",
                                                                                                   "start_timestamp"]}},
    "002": {"name": "EnvironmentId",
            "api": "datasources/aws/environments",
            "header": "application/api.clumio.aws-environments=v1+json",
            "version": "v1",
            "desc": "List AWS environments",
            "type": "get",
            "success": 200,
            "queryParms": {
                            "limit": 100,
                            "start": 1,
                            "filter": {
                               "account_native_id": [
                                   "$eq",
                                   "$begins_with"],
                               "aws_region": ["$eq"],
                               "connection_status": [
                                   "$eq"],
                               "services_enabled": [
                                   "$contains"]
                            },
                            "embed": [
                                        "read-aws-environment-ebs-volumes-compliance-stats",
                                        "read-aws-environment-ec2-instances-compliance-stats",
                                        "read-aws-environment-rds-resources-compliance-stats",
                                        "read-aws-environment-dynamodb-tables-compliance-stats",
                                        "read-aws-environment-protection-groups-compliance-stats",
                                        "read-aws-environment-ec2-mssql-compliance-stats"
                            ]
                           }
            },
    "003": {"name": "RestoreEC2",
            "api": "restores/aws/ec2-instances",
            "header": "application/api.clumio.restored-aws-ec2-instances=v1+json",
            "version": "v1",
            "bodyParms": {"source": None,"target":["ami_restore_target","instance_restore_target","volumes_restore_target"]},
            "PayloadTemplates": {
                "ebs_block_device_mappings": {
                    "condition":{"xor":[],"and":["volume_native_id"]},
                    "volume_native_id":None,
                    "kms_key_native_id":None,
                    "name":None,
                    "tags": {}
                },
                "network_interfaces":{
                    "condition":{"xor":[],"and":["device_index"]},
                    "device_index": None,
                    "network_interface_native_id": None,
                    "restore_default": False,
                    "restore_from_backup": False,
                    "security_group_native_ids": [None],
                    "subnet_native_id": None
                },
                "tags": {
                    "condition":{"xor":[],"and":["key","value"]},
                    "key": None,
                    "value": None
                },
                "ami_restore_target": {
                    "condition":{"xor":[],"and":["ebs_block_device_mappings","environment_id","name"]},
                    "description":None,
                    "ebs_block_device_mappings": {},
                    "environment_id":None,
                    "name":None,
                    "tags":{}
                },
                "volumes_restore_target": {
                    "condition":{"xor":["aws_az","target_instance_native_id"],"and":["ebs_block_device_mappings","environment_id"]},
                    "aws_az":None,
                    "ebs_block_device_mappings": {},
                    "target_instance_native_id": None,
                    "environment_id":None
                },
                "instance_restore_target": {
                    "condition":{"xor":[],"and":["ebs_block_device_mappings","environment_id","network_interfaces","subnet_native_id","vpc_native_id"]},
                    "should_power_on": False,
                    "ami_native_id": None,
                    "aws_az": None,
                    "ebs_block_device_mappings": {},
                    "environment_id":None,
                    "iam_instance_profile_name": None,
                    "key_pair_name": None,
                    "subnet_native_id": None,
                    "tags":{},
                    "vpc_native_id": None,
                    "network_interfaces": {}
                }
           },
            "desc": "Restore an EC2 instance",
            "type": "post",
            "success": 202,
            "queryParms": {
                           "embed": [
                               "read-task"
                           ]
            }
    },
    "004": {"name": "EBSBackupList",
            "api": "backups/aws/ebs-volumes",
            "header": "application/api.clumio.backup-aws-ebs-volumes=v2+json",
            "version": "v2",
            "desc": "List EBS volume backups",
            "type": "get",
            "success": 200,
            "queryParms": {
                "limit": 100,
                "start": 1,
                "filter": {
                    "start_timestamp": [
                        "$lte", "$gt"],
                    "volume_id": [
                        "$eq"]
                },
                "sort": [
                    "-start_timestamp",
                    "start_timestamp"]
            }
    },
    "005": {"name": "RestoreEBS",
            "api": "restores/aws/ebs-volumes",
            "header": "application/api.clumio.restored-aws-ebs-volumes=v2+json",
            "version": "v2",
            "bodyParms": {"source": None,
                          "target": {"condition": {"xor": [], "and": ["aws_az","environment_id"]},
                                    "aws_az" : None,
                                    "environment_id": None,
                                     "iops": 0,
                                     "kms_key_native_id": None,
                                     "tags": {},
                                     "type": None
                                     }
                          },
            "desc": "Restore an EBS Volume",
            "type": "post",
            "success": 202,
            "queryParms": {
                "embed": [
                    "read-task"
                ]
            }
    },
    "006": {"name": "ListEC2Instances",
                "api": "datasources/aws/ec2-instances",
                "header": "application/api.clumio.aws-ec2-instances=v1+json",
                "version": "v1",
                "desc": "List EC2 instances",
                "type": "get",
                "success": 200,
                "queryParms": {
                    "limit": 100,
                    "start": 1,
                    "filter": {
                        "environment_id": [
                            "$eq"],
                        "name": [
                            "$contains", "$eq"],
                        "instance_native_id": [
                            "$contains", "$eq"],
                        "account_native_id": [
                            "$eq"],
                        "compliance_status": [
                            {"$eq": ["compliant", "non_compliant"]}],
                        "protection_status": [
                            {"$eq": ["protected", "unprotected", "unsupported"]}],
                        "tags.id": [
                            "$all"],
                        "is_deleted": [
                            {"$eq": ["true","false"]}],
                        "availability_zone": [
                            "$eq"]
                    },
                    "embed": [
                        "read-policy-definition"
                    ]
                }
    },
    "007": {"name": "BackupEC2",
            "api": "backups/aws/ec2-instances",
            "header": "application/api.clumio.backup-aws-ec2-instances=v1+json",
            "version": "v2",
            "bodyParms": {
                                "type:": {
                                                "condition": {"xor": ["clumio_backup", "aws_snapshot"], "and": []}
                                },
                                "instance_id": None,
                                "setting": {
                                                "retention_duration": {
                                                    "condition": {"xor": [], "and": ["unit", "value"]},
                                                    "unit": {"condition": {"xor": ["hours","days","weeks","months","years"], "and": []}},
                                                    "value": 0
                                                },
                                                "advanced_settings": {
                                                                "condition": {"xor": ["aws_ebs_volume_backup","aws_ec2_instance_backup"], "and": []},
                                                                "aws_ebs_volume_backup": {"condition": {"xor": ["standard","lite"], "and": []}},
                                                                "aws_ec2_instance_backup": {"condition": {"xor": ["standard","lite"], "and": []}},
                                                },
                                                "backup_aws_region": None
                                },
            },
            "desc": "Backup an EC2 instance on demand",
            "type": "post",
            "success": 202,
            "queryParms": {
                "embed": [
                    "read-task"
                ]
            }
    },
    "999": {"api": "test002", "version": "v1", "desc": 'List EC2 instance backups', "type": "get", "success": 200,
            "payload": {"a": 73, "b": "bye", "theRitz": "Gazila"}},
}


class API:
    def __init__(self, id):
        self.id = id
        self.good = True
        self.name = apiDICT.get(id, {}).get('api', None)
        self.version = apiDICT.get(id, {}).get('version', None)
        self.type = apiDICT.get(id, {}).get('type', None)
        self.Pagnation = False
        self.Debug = 40
        if apiDICT.get(id, {}).get('success', None):
            self.success = apiDICT.get(id, {}).get('success', None)
        else:
            if self.Debug > 7: print(
                f"API init debug new APIs {id},  success {apiDICT.get(id, {}).get('success', None)}")
            self.good = False

        self.urlPrefix = "https://us-west-2.api.clumio.com/"
        self.header = {}
        self.payload = {}
        self.payloadFlag = False
        self.bodyParmsFlag = False
        self.bodyParms = {}
        self.tokenFlag = False
        self.token = None
        self.good = True
        self.typeGET = False
        self.typePOST = False
        self.current_count = 0
        self.total_count = 0
        self.total_pages_count = 0
        self.ErrorMsg = None
        self.ExecErrorFlag = False
        self.AWSAccountId = "080005437757"
        self.aws_account_id_flag = False
        self.AWSRegion = "us-east-1"
        self.aws_region_flag = False
        self.regionOption = ["us-east-1", "us-west-2", "us-east-2", "us-west-1"]
        self.AWSTagKey = ""
        self.AWSTagValue = ""
        self.AWSTagFlag = False
        self.UsageType = "S3"
        self.AWSCredentials = None
        self.AWSConnectGood = False
        self.DumpToFileFlag = False
        self.DumpFileName = None
        self.DumpBucket = None
        self.AWSBucketRegion = None
        self.FileIAMRole = None
        self.ImportBucket = None
        self.AWSImportBucketRegion = None
        self.ImportFileName = None
        self.ImportFileFlag = False
        self.ImportData = {}
        self.typePOST = False
        # #print("Hello world its me Dave")
        # Function to Create an AWS Session using IAM role

        if apiDICT.get(id, {}).get('header', None):
            self.acceptAPI = apiDICT.get(id, {}).get('header', None)
        else:
            if self.Debug > 7: print(
                f"API init debug new APIs {id},  header {apiDICT.get(id, {}).get('header', None)}")
            self.good = False
        # #print(f"DICT {apiDICT.get(id, {}).get('type', None)}")
        if apiDICT.get(id, {}).get('type', None):
            type = apiDICT.get(id, {}).get('type', None)
            if type == 'get':
                self.typeGET = True
                # #print("found get")
            elif type == 'post':
                self.typePOST = True
            else:
                if self.Debug > 7: print(
                    f"API init debug new APIs {id},  type {apiDICT.get(id, {}).get('type', None)}")
                self.good = False
        else:
            if self.Debug > 7: print(
                f"API init debug new APIs {id},  type {apiDICT.get(id, {}).get('type', None)}")
            self.good = False
        if apiDICT.get(id, {}).get('api', None):
            self.url = self.urlPrefix + apiDICT.get(id, {}).get('api', None)
            self.urlFull = self.url
        else:
            self.good = False
        if apiDICT.get(id, {}).get('bodyParms', False):
            self.bodyParmsFlag = True
            self.bodyParms = apiDICT.get(id, {}).get('bodyParms', {})
        else:
            self.payloadFlag = False
            self.payload = {}
        if apiDICT.get(id, {}).get('queryParms', False):
            self.queryParmsFlag = True
            self.queryParms = apiDICT.get(id, {}).get('queryParms', {})
        else:
            self.queryParmsFlag = False
            self.queryParms = {}
        if apiDICT.get(id, {}).get('bodyParms', False):
            self.bodyParmsFlag = True
            self.bodyParms = apiDICT.get(id, {}).get('bodyParms', {})
        else:
            self.bodyParmsFlag = False
            self.bodyParms = {}
        if apiDICT.get(id, {}).get('pathParms', False):
            self.pathParmsFlag = True
            self.pathParms = apiDICT.get(id, {}).get('queryParms', {})
        else:
            self.pathParmsFlag = False
            self.pathParms = {}

    # Set Debug Level
    def SetDebug(self,value):
        try:
            self.Debug = int(value)
            return True
        except ValueError:
            return False

    # Function for user to setup Dump file to S3
    def SetupDumpFileS3(self, filename, bucket, prefix, role, AWSSession, region="us-east-2"):
        self.UsageType = "S3"
        self.AWSBucketRegion = region

        if self.SetDumpBucket(bucket):
            self.SetIAMFileRole(role)

            if self.ConnectAWS(AWSSession):

                s3FilePath = f"{prefix}/{filename}"
                if self.SetDumpFile(s3FilePath, True):

                    self.DumpToFileFlag = True
                    return True
        if self.Debug > 3: print(f"SetDUmpFileS3 failed {filename}, {bucket}, {prefix}, {role}, {AWSSession}, {region}")
        return False

    # Function to set Dump to File option
    def SetDumpFile(self, filename, timestampFlag=False):

        CHECK_RE = re.compile('[a-zA-Z0-9_/-]+$')

        if CHECK_RE.match(filename):

            # If use timestamp flag is passed add timestamp to file name
            if timestampFlag:

                today = datetime.now().astimezone(timezone.utc)

                NowDateStr = today.strftime('%Y%m%d%H%M%S')
                self.DumpFileName = f"{filename}-{NowDateStr}.json"

            else:

                self.DumpFileName = f"{filename}.json"
            return True
        if self.Debug > 3: print(f"SetDumpFile failed {filename}, {timestampFlag}")
        return False

    # Function to set Dump Bucket
    def SetDumpBucket(self, bucket):
        # Only allow lower case characters, numbers, -
        CHECK_RE = re.compile('[a-z0-9-]+$')

        if CHECK_RE.match(bucket):

            self.DumpBucket = bucket
            return True
        else:
            status_msg = f"failed {bucket} is invalid name format"
            self.ErrorMsg = f"status {status_msg}"
            if self.Debug > 3: print(f"SetDumpBucket failed {bucket}")
            return False

    def SetIAMFileRole(self, role):
        self.FileIAMRole = role

    # Function to clear Dump to File option
    def ClearDumpToFile(self):
        self.DumpToFileFlag = False

    def DataDump(self, DictData):

        if self.UsageType == "S3" and self.AWSConnectGood:

            jsonData = json.dumps(DictData, indent=2)
            S3Key = self.DumpFileName
            AccessKeyId = self.AWSCredentials.get("AccessKeyId", None)
            SecretAccessKey = self.AWSCredentials.get('SecretAccessKey', None)
            SessionToken = self.AWSCredentials.get('SessionToken', None)
            region = self.AWSBucketRegion
            try:
                AWSsession = boto3.Session(
                    aws_access_key_id=AccessKeyId,
                    aws_secret_access_key=SecretAccessKey,
                    aws_session_token=SessionToken,
                    region_name=region
                )
            except ClientError as e:
                ERROR = e.response['Error']['Code']
                self.ErrorMsg = "failed to initiate session {ERROR}"
                if self.Debug > 3: print(f"DataDump failed in AWS Session cmd {DictData}")
                return False
            s3_client = AWSsession.client("s3")
            s3_resource = AWSsession.resource('s3')
            dataEncoded = jsonData.encode('ascii')
            object1 = s3_resource.Object(self.DumpBucket, S3Key)
            try:
                result = object1.put(Body=dataEncoded)
            except ClientError as e:
                ERROR = e.response['Error']['Code']
                status_msg = f"failed to write ClumioResourceList file {Key1}"
                self.ErrorMsg = f"status: {status_msg}, msg: {ERROR}"
                if self.Debug > 3: print(f"DataDump failed in AWS s3 put cmd {DictData}")
                return False
            return result
        else:
            self.ErrorMsg = "status: not supporting other dump methods yet"
            return False

    # Function to Create an AWS Session using IAM role
    def ConnectAWS(self, session):

        if self.UsageType == "S3":

            # BOILER PLATE AWS CONNECT STUFF
            client = session.client('sts')
            if self.FileIAMRole:

                roleArn = self.FileIAMRole
                externalId = "clumio"
                sessionName = "mysesino"
                try:
                    response = client.assume_role(
                        RoleArn=roleArn,
                        RoleSessionName=sessionName,
                        ExternalId=externalId
                    )
                except ClientError as e:
                    ERROR = e.response['Error']['Code']
                    status_msg = f"failed to assume role {roleArn}"
                    self.ErrorMsg = f"status {status_msg} Error {ERROR}"
                    if self.Debug > 3: print(f"ConnectAWS failed in AWS s3 assume role cmd {session}")
                    return False
                Credentials = response.get('Credentials', None)
                if not Credentials == None:
                    # #print("in ConnectAWS 05")
                    AccessKeyId = Credentials.get("AccessKeyId", None)
                    SecretAccessKey = Credentials.get('SecretAccessKey', None)
                    SessionToken = Credentials.get('SessionToken', None)
                    if not AccessKeyId == None and not SecretAccessKey == None and not SessionToken == None:
                        # #print(f"status: passed, AccessKeyId: {AccessKeyId}, SecretAccessKey: {SecretAccessKey},SessionToken: {SessionToken}")
                        self.AWSCredentials = Credentials
                        self.AWSConnectGood = True
                        return True
                    else:
                        # #print("in ConnectAWS 05")
                        status_msg = "failed AccessKey or SecretKey or SessionToken are blank"
                        self.ErrorMsg = f"status {status_msg}"
                        # #print(status_msg)
                        # return {"status": status_msg, "msg": ""}
                else:
                    # #print("in ConnectAWS 06")
                    status_msg = "failed Credentilas are blank"
                    self.ErrorMsg = f"status {status_msg}"
            else:
                # #print("in ConnectAWS 07")
                status_msg = "failed Role is blank"
                self.ErrorMsg = f"status {status_msg}"
        else:
            # #print("in ConnectAWS 08")
            status_msg = "Usage Type is not S3"
            self.ErrorMsg = f"status {status_msg}"
        # #print("in ConnectAWS 09")
        self.AWSConnectGood = False
        if self.Debug > 3: print(f"ConnectAWS failed ErrorMsg {self.ErrorMsg}, {session}")
        return False
        # END OF BOILER PLATE

    def GetError(self):
        return self.ErrorMsg

    def GetVersion(self):
        # #print(self.version,type(self.version))
        ##print("hi")
        return self.version

    def SetToken(self, token):
        self.token = token
        self.tokenFlag = True
        bear = f"Bearer {self.token}"

        if self.good:
            if self.typeGET:
                self.header = {"accept": self.acceptAPI, "authorization": bear}
            elif self.typePOST:
                self.header = {"accept": self.acceptAPI,"content-type": "application/json", "authorization": bear}
            return self.header

    def SetURL(self, prefix):
        # #print(f"hi in set {prefix}")
        if self.good:
            self.urlFull = self.url + prefix
            # #print(self.urlFull)

    def GetURL(self):
        if self.good:
            return self.urlFull
        else:
            return False

    def SetPagnation(self):
        self.Pagnation = True

    def GetHeader(self):
        if self.good:
            return self.header
        else:
            return False

    def SetBad(self):
        self.good = False

    def SetGET(self):

        self.typeGET = True

    def SetPOST(self):

        self.typePOST = True

    def SetAWSTagKey(self, AWSTagKey):
        self.AWSTagKey = AWSTagKey
        self.AWSTagFlag = True
        if self.Debug > 5: print(f"SetAWSTagKey: value {AWSTagKey}")
        return True

    def ClearAWSTag(self):
        self.AWSTagKey = ""
        self.AWSTagValue = ""
        self.AWSTagFlag = False

    def SetAWSTagValue(self, AWSTagValue=None):
        self.AWSTagValue = AWSTagValue
        return True

    def SetAWSAccountId(self, AWSAccountId):
        try:
            int(AWSAccountId)
            self.AWSAccountId = AWSAccountId
            self.aws_account_id_flag_flag = False
            return True
        except ValueError:
            return False

    def SetAWSRegion(self, AWSRegion):

        if AWSRegion in self.regionOption:

            self.AWSRegion = AWSRegion
            self.aws_region_flag = True
            return True
        else:
            return False

    def ExecAPI(self):
        if self.Debug > 7: print(f"ExecAPI: In Post {self.id},  type post {self.typePOST} type get {self.typeGET}")
        if self.typeGET:

            if self.good and self.tokenFlag:

                url = self.GetURL()
                header = self.GetHeader()
                if self.Debug > 0: print(f"ExecAPI - url {url}")
                if self.Debug > 0: print(f"ExecAPI - header {header}")

                try:
                    response = requests.get(url, headers=header)
                except ClientError as e:
                    ERROR = e.response['Error']['Code']
                    status_msg = "failed to initiate session"
                    if self.Debug > 3: print("ExecAPI failed in request")
                    return {"status": status_msg, "msg": ERROR}
                status = response.status_code

                resposneText = response.text
                if self.Debug > 1: print(f"ExecAPI - get request response {resposneText}")
                responseDICT = json.loads(resposneText)

                if not status == self.success:
                    status_msg = f"API status {status}"
                    ERROR = responseDICT.get('errors')
                    self.ExecErrorFlag = True
                    self.ErrorMsg = f"status: {status_msg}, msg: {ERROR}"
                    if self.Debug > 3: print(f"ExecAPI get request error resonse - {self.ErrorMsg}")
                    self.good = False
                if self.Pagnation:
                    self.current_count = responseDICT.get("current_count")
                    self.total_count = responseDICT.get("total_count")
                    self.total_pages_count = responseDICT.get("total_pages_count")
                    if self.Debug > 1: print(f"ExecAPI - pagination info current, total, total pages {self.current_count} {self.total_count} {self.total_pages_count}")
                return responseDICT
        elif self.typePOST:
            if self.Debug > 7: print(f"ExecAPI: post Post  {id},  header {apiDICT.get(id, {}).get('header', None)}")
            if self.good and self.tokenFlag and self.payloadFlag:
                if self.Debug > 7: print(f"ExecAPI: In Post {id},  header {apiDICT.get(id, {}).get('header', None)}")
                url = self.GetURL()
                header = self.GetHeader()
                payload = self.GetPayload()
                if self.Debug > 0: print(f"ExecAPI - url {url}")
                if self.Debug > 0: print(f"ExecAPI - header {header}")
                if self.Debug > 0: print(f"ExecAPI - payload {payload}")
                try:
                    response = requests.post(url, json=payload, headers=header)

                except ClientError as e:
                    ERROR = e.response['Error']['Code']
                    status_msg = "failed to initiate session"
                    if self.Debug > 3: print(f"ExecAPI post request failed - {self.ErrorMsg}")
                    return {"status": status_msg, "msg": ERROR}
                status = response.status_code

                resposneText = response.text
                if self.Debug > 1: print(f"ExecAPI - request response {resposneText}")
                responseDICT = json.loads(resposneText)

                if not status == self.success:
                    status_msg = f"API status {status}"
                    ERROR = responseDICT.get('errors')
                    self.ExecErrorFlag = True
                    self.ErrorMsg = f"status: {status_msg}, msg: {ERROR}"
                    self.good = False
                    if self.Debug > 3: print(f"ExecAPI post request resonse - {self.ErrorMsg}")
                return responseDICT
        else:
            self.good = False
            return False
    # Function to set Import Bucket
    def SetImportBucket(self, bucket):
        # Only allow lower case characters, numbers, -
        CHECK_RE = re.compile('[a-z0-9-]+$')
        if CHECK_RE.match(bucket):
            self.ImportBucket = bucket
            return True
        else:
            status_msg = f"failed {bucket} is invalid name format"
            self.ErrorMsg = f"status {status_msg}"
            # #print("in SetUploadBucket 03")
            return False

    def SetupImportFileS3(self, filename, bucket, prefix, role, AWSSession, region="us-east-2"):
        self.UsageType = "S3"
        self.AWSBucketRegion = region
        #print("in SetupFileS3 01")
        if self.SetImportBucket(bucket):
            #print("in SetupFileS3 02")
            self.SetIAMFileRole(role)
            # #print("in SetupDumpFileS3 02")
            if self.ConnectAWS(AWSSession):
                #print("in SetupDumpFileS3 03")
                s3FilePath = f"{prefix}/{filename}"
                if self.SetImportFile(s3FilePath):
                    #print("in SetupFileS3 04")
                    return True
        return False

    # Function to set Upload from File option
    def SetImportFile(self, filename):
        #print(f"SetImportFile 01 {filename}")
        self.ImportFileName = filename
        self.ImportFileFlag = True
        return True

        # Function to clear import File option

    def ClearImportFile(self, filename):
        self.ImportFileName = None
        self.ImportFileFlag = False

    def DataImport(self):
        if self.UsageType == "S3" and self.ImportFileFlag and self.AWSConnectGood:
            # jsonData = json.dumps(DictData, indent=2)
            S3Key = self.ImportFileName
            AccessKeyId = self.AWSCredentials.get("AccessKeyId", None)
            SecretAccessKey = self.AWSCredentials.get('SecretAccessKey', None)
            SessionToken = self.AWSCredentials.get('SessionToken', None)
            region = self.AWSBucketRegion
            try:
                AWSsession = boto3.Session(
                    aws_access_key_id=AccessKeyId,
                    aws_secret_access_key=SecretAccessKey,
                    aws_session_token=SessionToken,
                    region_name=region
                )
            except ClientError as e:
                ERROR = e.response['Error']['Code']
                self.ErrorMsg = "failed to initiate session {ERROR}"
                # #print("in DataDump 03")
                return False
            s3_client = AWSsession.client("s3")
            s3_resource = AWSsession.resource('s3')

            try:

                obj3 = s3_resource.Object(self.ImportBucket, S3Key)
                jsonFile3 = obj3.get()['Body'].read().decode('utf-8')
                self.ImportData = json.loads(jsonFile3)
                #print(type(self.ImportData), self.ImportData)
            except ClientError as e:
                ERROR = e.response['Error']['Code']
                status_msg = f"failed read input file{ClumioResourceFile}"
                #print(f"status: {status_msg}, msg: {ERROR}")
                self.ErrorMsg = f"status: {status_msg}, msg: {ERROR}"
                return False

            return True
        else:
            self.ErrorMsg = "status: not supporting other import methods yet"
            return False
    def ClearPayload(self):
        self.payload = none
        self.payloadFlag = False

    def GetPayload(self):
        if self.payloadFlag:
            return self.payload

class EC2BackupList(API):
    def __init__(self):
        super(EC2BackupList, self).__init__("001")
        self.id = "001"
        self.filterList = []
        self.filterExpression = {}
        self.filterExpressionString = ""
        self.filterExpressionStringEnc = ""
        self.limitExpressionString = ""
        self.startExpressionString = ""
        self.sortExpressionString = ""
        self.filterFlag = False
        self.limitFlag = False
        self.startFlag = False
        self.sortFlag = False
        self.limit = 100
        self.start = 1
        self.URLSuffixList = []
        self.URLSuffixListEnc = []
        self.URLSuffixString = ""
        self.URLSuffixStringEnc = ""
        self.HTMLURLSuffSting = ""
        self.typeGet = False
        self.typePost = False
        self.SetPagnation()
        self.GoodRunFlag = True
        self.filterExpression = None
        self.startDayTimeStamp = None
        self.SearchInstanceId = None
        self.searchType = None
        self.searchStartDay = 0
        self.searchEndDay = 10
        self.TagNameMatch = ""
        self.TagValueMatch = ""
        self.SeachInstnaceId = ""
        self.SearchInstanceIdFlag = False
        # self.filterExpression = "$lte"
        self.StartHour = "22"
        self.StartMin = "58"
        self.StartSec = "58"
        self.endDate = None
        self.SetSort("-start_timestamp")
        self.CurrentEc2InstanceIdTimeStamp = {}
        self.CurrentEC2InstanceInfo = {}
        self.SetPagnation()
        #print(f"RestoreEC2 why apiDICT {apiDICT.get(self.id, {}).get('type', None)}")
        if apiDICT.get(self.id, {}).get('type', None):
            #print(f"apiDICT 01")
            if self.good:
                #print(f"apiDICT 02")
                if apiDICT.get(self.id, {}).get('type', None) == "get":
                    #print(f"apiDICT 03")
                    self.SetGET()
                elif apiDICT.get(self.id, {}).get('type', None) == "post":
                    #print(f"apiDICT 04")
                    self.SetPOST()
                else:
                    #print(f"apiDICT 05")
                    self.SetBad()

    def runAll(self):
        if self.searchType:
            DayStartDelta = self.searchStartDay
            DayEndDelta = self.searchEndDay
            #print(f"the delta start end {DayStartDelta} {DayEndDelta}")
            if self.searchType == "After":
                if DayStartDelta > DayEndDelta:
                    self.ErrorMsg = "Search Start day is older then search end day"
                    return False
                today = datetime.now().astimezone(timezone.utc)
                startDelta = timedelta(days=DayStartDelta)
                endDelta = timedelta(days=DayEndDelta)
                startDate = today - startDelta
                self.endDate = today - endDelta
                # #print(startDate)
                if startDate.year < 10:
                    startDateYear = "0" + str(startDate.year)
                else:
                    startDateYear = str(startDate.year)
                if startDate.month < 10:
                    startDateMonth = "0" + str(startDate.month)
                else:
                    startDateMonth = str(startDate.month)
                if startDate.day < 10:
                    startDateDay = "0" + str(startDate.day)
                else:
                    startDateDay = str(startDate.day)
                self.startDayTimeStamp = f"{startDateYear}-{startDateMonth}-{startDateDay}T{self.StartHour}:{self.StartMin}:{self.StartSec}Z"
            elif self.searchType == "Before":
                today = datetime.now().astimezone(timezone.utc)
                endDelta = timedelta(days=DayEndDelta)
                endDate = today - endDelta
                # #print(startDate)
                if endDate.year < 10:
                    endDateYear = "0" + str(endDate.year)
                else:
                    endDateYear = str(endDate.year)
                if endDate.month < 10:
                    endDateMonth = "0" + str(endDate.month)
                else:
                    endDateMonth = str(endDate.month)
                if endDate.day < 10:
                    endDateDay = "0" + str(endDate.day)
                else:
                    endDateDay = str(endDate.day)
                # startDateMonth = str(startDate.month)
                # startDateDay = str(startDate.day)
                self.startDayTimeStamp = f"{endDateYear}-{endDateMonth}-{endDateDay}T{self.StartHour}:{self.StartMin}:{self.StartSec}Z"
            self.SetFilter("start_timestamp", self.filterExpression, self.startDayTimeStamp)
        if self.SearchInstanceIdFlag:
            self.SetFilter("instance_id", "$eq", self.SearchInstanceId)
        self.Results = []
        FirstResults = self.ExecAPI()
        if self.good:
            items = FirstResults.get("_embedded", {}).get("items", {})
            for i in items:
                check = self.PassCheck(i)
                if check:
                    self.CurrentEC2InstanceInfo[check] = i
        else:
            return False
        if self.total_pages_count:
            if self.total_pages_count > 1:
                for i in range(2, self.total_pages_count):
                    self.SetPageStart(i)
                    NextResults = self.ExecAPI()
                    if self.good:
                        items = NextResults.get("_embedded", {}).get("items", {})
                        for i in items:
                            check = self.PassCheck(i)
                            if check:
                                self.CurrentEC2InstanceInfo[check] = i
                    else:
                        return False
                    # #print(f"read page {i}")
        return len(self.CurrentEC2InstanceInfo)

    def PassCheck(self, response):
        awsRegion = response.get("aws_region", None)
        awsAccountId = response.get("account_native_id", None)
        if not (awsRegion == self.AWSRegion and awsAccountId == self.AWSAccountId):
            return False
        if self.AWSTagFlag:
            tags = response.get("tags", None)
            FoundTag = False
            for tag in tags:
                if tag.get("key", None) == self.AWSTagKey and tag.get("value", None) == self.AWSTagValue:
                    FoundTag = True
            if not FoundTag:
                return False
        time_stamp = response.get("start_timestamp", None)
        clumio_instance_id = response.get("instance_id", None)
        new_date = datetime.fromisoformat(time_stamp[:-1]).astimezone(timezone.utc)
        if self.searchType == "After":
            # new_date = datetime.fromisoformat(time_stamp[:-1]).astimezone(timezone.utc)
            if self.CurrentEc2InstanceIdTimeStamp.get(clumio_instance_id, None):
                if new_date > self.CurrentEc2InstanceIdTimeStamp.get(clumio_instance_id, None):
                    self.CurrentEc2InstanceIdTimeStamp[clumio_instance_id] = new_date
                    return clumio_instance_id
                else:
                    return False
            else:
                if new_date > self.endDate:
                    return clumio_instance_id
                else:
                    return False
        else:
            if self.CurrentEc2InstanceIdTimeStamp.get(clumio_instance_id, None):
                if new_date > self.CurrentEc2InstanceIdTimeStamp.get(clumio_instance_id, None):
                    self.CurrentEc2InstanceIdTimeStamp[clumio_instance_id] = new_date
                    return clumio_instance_id
                else:
                    return False
            else:
                self.CurrentEc2InstanceIdTimeStamp[clumio_instance_id] = new_date
                return clumio_instance_id

    def EC2ParseResults(self, ParseType):
        ExampleParmsList = [
            "ID :BackupIds & InstanceIds & TimeStamp",
            "Restore :Parameters Needed for EC2 Restore",
            "Count : Number of Instances",
            "All : All Data"
        ]
        records = []
        if ParseType == "ID":
            for inst in self.CurrentEC2InstanceInfo.keys():
                rec = {"IDRecord": [self.CurrentEC2InstanceInfo[inst].get("instance_native_id", None),
                                    self.CurrentEC2InstanceInfo[inst].get("id", None),
                                    self.CurrentEC2InstanceInfo[inst].get("start_timestamp", None)]}
                records.append(rec)
            clumio_resource_list_dict = {"Records": records}
            if self.DumpToFileFlag:
                # #print("in the dumpining 01")
                if not self.DataDump(clumio_resource_list_dict):
                    return False
            return clumio_resource_list_dict
        elif ParseType == "ALL":
            for inst in self.CurrentEC2InstanceInfo.keys():
                rec = {"item": self.CurrentEC2InstanceInfo[inst]}
                records.append(rec)
            clumio_resource_list_dict = {"Records": records}
            if self.DumpToFileFlag:
                # #print("in the dumpining 01")
                if not self.DataDump(clumio_resource_list_dict):
                    return False
            return clumio_resource_list_dict
        elif ParseType == "Restore":
            for inst in self.CurrentEC2InstanceInfo.keys():
                rec = {"instanceId": self.CurrentEC2InstanceInfo[inst].get("instance_native_id", None),
                       "backupRecord": {
                           "SourceBackupId": self.CurrentEC2InstanceInfo[inst].get("id", None),
                           "SourceAmiId": self.CurrentEC2InstanceInfo[inst].get("ami",{}).get("ami_native_id",None),
                           "SourceIAMInstanceProfileName": self.CurrentEC2InstanceInfo[inst].get("iam_instance_profile",
                                                                                                 None),
                           "SourceKeyPairName": self.CurrentEC2InstanceInfo[inst].get("key_pair_name", None),
                           "SourceNetworkInterfaceList": self.CurrentEC2InstanceInfo[inst].get("network_interfaces",
                                                                                               []),
                           "SourceEBSStorageList": self.CurrentEC2InstanceInfo[inst].get("attached_backup_ebs_volumes",
                                                                                         []),
                           "SourceInstanceTags": self.CurrentEC2InstanceInfo[inst].get("tags", []),
                           "SourceVPCID": self.CurrentEC2InstanceInfo[inst].get("vpc_native_id", []),
                           "SourceAZ": self.CurrentEC2InstanceInfo[inst].get("aws_az", []),
                           "SourceExpireTime": self.CurrentEC2InstanceInfo[inst].get("expiration_timestamp", []),
                       }
                       }
                records.append(rec)
            clumio_resource_list_dict = {"Records": records}
            if self.DumpToFileFlag:
                # #print("in the dumpining 01")
                if not self.DataDump(clumio_resource_list_dict):
                    return False
            return clumio_resource_list_dict
        return {}

    def EC2SearchByTag(self, Key, Value):
        self.SetAWSTagKey(Key)
        self.SetAWSTagValue(Value)

    def SetPageSize(self, x):
        if self.queryParmsFlag:
            if "limit" in self.queryParms.keys():
                self.limit = x
                self.limitExpressionString = "limit=" + str(self.limit)
                self.limitFlag = True
                return self.BuildURLSuffix()
        self.SetBad()
        return None

    def SetPageStart(self, x):
        if self.queryParmsFlag:
            if "start" in self.queryParms.keys():
                self.start = x
                self.startExpressionString = "start=" + str(self.start)
                self.startFlag = True
                return self.BuildURLSuffix()
        self.SetBad()
        return None

    def BuildURLSuffix(self):
        self.URLSuffixList = []
        if self.good:
            if self.filterFlag:
                self.URLSuffixList.append(self.filterExpressionStringEnc)

            if self.sortFlag:
                self.URLSuffixList.append(self.sortExpressionString)

            if self.limitFlag:
                self.URLSuffixList.append(self.limitExpressionString)

            if self.startFlag:
                self.URLSuffixList.append(self.startExpressionString)

            self.URLSuffString = "?" + "&".join(self.URLSuffixList)
            String = self.URLSuffString
            # #print(String)
            self.SetURL(String)
            return self.URLSuffString

    def SetFilter(self, filterName, filterExpression, filterValue):
        filterExpressionDict = {}
        #print(f"setFilter 01 {filterName}")
        if self.queryParmsFlag:
            #print("setFilter 02")
            if filterName in self.queryParms.get("filter", {}).keys():
                #print("setFilter 03")
                if filterExpression in self.queryParms.get("filter", {}).get(filterName, []):
                    #print("setFilter 04")
                    self.filterList.append([filterName, filterExpression, filterValue])
                    for i in self.filterList:
                        ##print(f"in SetFilter 05 {i}")
                        filterExpressionDict[i[0]] = {i[1]: i[2]}
                    self.filterExpressionString = "filter=" + json.dumps(filterExpressionDict, separators=(',', ':'))
                    self.filterExpressionStringEnc = "filter=" + urllib.parse.quote(
                        json.dumps(filterExpressionDict, separators=(',', ':')))
                    self.filterFlag = True
                    return self.BuildURLSuffix()
        self.SetBad()
        return None

    def SetSort(self, sortName):

        if self.queryParmsFlag:
            if sortName in self.queryParms.get("sort", []):
                self.sortExpressionString = "sort=" + sortName
                self.sortFlag = True
                return self.BuildURLSuffix()
        self.SetBad()
        return None

    def SetSearchInstanceId(self, instance_id):
        self.SearchInstanceIdFlag = True
        self.SearchInstanceId = instance_id

    def SetSearchTimeFrameBeforeAfter(self, searchType):
        self.searchType = searchType
        if self.searchType == "Before":
            self.filterExpression = "$gt"
            self.StartHour = "00"
            self.StartMin = "00"
            self.StartSec = "00"
        elif self.searchType == "After":
            self.filterExpression = "$lte"
            self.StartHour = "23"
            self.StartMin = "59"
            self.StartSec = "59"
        else:
            self.GoodRunFlag = False

    def SetSearchStartDay(self, startDay):
        try:
            int(startDay)
            self.searchStartDay = startDay
        except ValueError:
            return False
        return True

    def SetSearchEndDay(self, endDay):
        try:
            int(endDay)
            self.searchEndDay = endDay
        except ValueError:
            return False
        return True


#NEXT API

class EnvironmentId(API):
    def __init__(self):
        super(EnvironmentId, self).__init__("002")
        self.id = "002"
        self.filterList = []
        # self.filterExpression = {}
        self.filterExpressionString = ""
        self.filterExpressionStringEnc = ""
        self.limitExpressionString = ""
        self.startExpressionString = ""
        self.embedExpressionString = ""
        self.filterFlag = False
        self.limitFlag = False
        self.startFlag = False
        # self.sortFlag = False
        self.embedFlag = False
        self.limit = 100
        self.start = 1
        self.URLSuffixList = []
        self.URLSuffixListEnc = []
        self.URLSuffixString = ""
        self.URLSuffixStringEnc = ""
        self.HTMLURLSuffSting = ""
        self.typeGet = True
        self.typePost = False
        self.SetPagnation()
        self.GoodRunFlag = True
        self.filterExpression = None
        self.SearchServiceFlag = False
        self.SearchService = None
        self.SearchAccountIdFlag = False
        self.SearchAccountId = None
        self.SearchStatusFlag = False
        self.SearchRegionFlag = False
        self.SearchRegion = None
        self.EnvironmentIdDict = {}
        #self.SetPagnation()

        #print(f"RestoreEC2 why apiDICT {apiDICT.get(self.id, {}).get('type', None)}")
        if apiDICT.get(self.id, {}).get('type', None):
            #print(f"apiDICT 01")
            if self.good:
                #print(f"apiDICT 02")
                if apiDICT.get(self.id, {}).get('type', None) == "get":
                    #print(f"apiDICT 03")
                    self.SetGET()
                elif apiDICT.get(self.id, {}).get('type', None) == "post":
                    #print(f"apiDICT 04")
                    self.SetPOST()
                else:
                    #print(f"apiDICT 05")
                    self.SetBad()
        #print(f"type of REST get {self.typeGet} post {self.typePost}")

    def runAll(self):
        if self.SearchAccountIdFlag:
            #print(f"set account {self.SearchAccountId}")
            self.SetFilterEnv("account_native_id", "$eq", self.SearchAccountId)
            #print(f"set account {self.SearchAccountId}")
        if self.SearchServiceFlag:
            self.SetFilterEnv("services_enabled", "$contains", self.SearchService)
        if self.SearchRegionFlag:
            #print(f"set account{self.SearchRegion}")
            self.SetFilterEnv("aws_region", "$eq", self.SearchRegion)
            #print(f"set account{self.SearchRegion}")
        self.Results = []
        FirstResults = self.ExecAPI()
        #print(f"run {FirstResults}")
        #print("Life of Brian",FirstResults)
        if self.good:
            items = FirstResults.get("_embedded", {}).get("items", {})
            for i in items:
                check = self.PassCheck(i)
                if check:
                    self.EnvironmentIdDict[check] = i
        else:
            return False
        if self.total_pages_count:
            if self.total_pages_count > 1:
                for i in range(2, self.total_pages_count):
                    self.SetPageStart(i)
                    NextResults = self.ExecAPI()
                    if self.good:
                        items = NextResults.get("_embedded", {}).get("items", {})
                        for i in items:
                            check = self.PassCheck(i)
                            if check:
                                self.EnvironmentIdDict[check] = i
                    else:
                        return False
                # #print(f"read page {i}")
        return len(self.EnvironmentIdDict)

    def PassCheck(self, response):
        environmentId = response.get("id", None)
        if environmentId:
            return environmentId
        else:
            return False

    def EnvironmentIdParseResults(self, ParseType="ID"):
        ExampleParmsList = [
            "ID :BackupIds & InstanceIds & TimeStamp",
            "Restore :Parameters Needed for EC2 Restore",
            "Count : Number of Instances",
            "All : All Data"
        ]
        records = []
        #print(self.EnvironmentIdDict)
        if ParseType == "ID":
            if self.EnvironmentIdDict:
                if len(self.EnvironmentIdDict.keys()) > 1:
                    return False
                else:
                    for key in self.EnvironmentIdDict.keys():
                        return key
            else:
                return False
        elif ParseType == "ALL":
            if self.EnvironmentIdDict:
                return self.EnvironmentIdDict
            else:
                return False
        return False

    def SetPageSize(self, x):
        if self.queryParmsFlag:
            if "limit" in self.queryParms.keys():
                self.limit = x
                self.limitExpressionString = "limit=" + str(self.limit)
                self.limitFlag = True
                return self.BuildURLSuffix()
        self.SetBad()
        return None

    def SetPageStart(self, x):
        if self.queryParmsFlag:
            if "start" in self.queryParms.keys():
                self.start = x
                self.startExpressionString = "start=" + str(self.start)
                self.startFlag = True
                return self.BuildURLSuffix()
        self.SetBad()
        return None

    def BuildURLSuffix(self):
        self.URLSuffixList = []
        if self.good:
            if self.filterFlag:
                self.URLSuffixList.append(self.filterExpressionStringEnc)

            if self.embedFlag:
                self.URLSuffixList.append(self.sortExpressionString)

            if self.limitFlag:
                self.URLSuffixList.append(self.limitExpressionString)

            if self.startFlag:
                self.URLSuffixList.append(self.startExpressionString)

            self.URLSuffString = "?" + "&".join(self.URLSuffixList)
            String = self.URLSuffString
            # #print(String)
            self.SetURL(String)
            return self.URLSuffString

    def SetFilterEnv(self, filterNameEnv, filterExpressionEnv, filterValueEnv):
        filterExpressionDict = {}
        #print(f"in SetFilter 01 {filterNameEnv} {filterExpressionEnv} {filterValueEnv}")
        if self.queryParmsFlag:
            #print("in SetFilter 02")
            if filterNameEnv in self.queryParms.get("filter", {}).keys():
                #print("in SetFilter 03")
                if filterExpressionEnv in self.queryParms.get("filter", {}).get(filterNameEnv, []):
                    #print(f"in SetFilter 04 {self.filterList}")
                    self.filterList.append([filterNameEnv, filterExpressionEnv, filterValueEnv])
                    #print(f"in SetFilter 04 {self.filterList}")

                    for i in self.filterList:
                        #print(f"in SetFilter 05 {i}")
                        filterExpressionDict[i[0]] = {i[1]: i[2]}
                        #print(f"in setFilter 07 {filterExpressionDict}")
                    self.filterExpressionString = "filter=" + json.dumps(filterExpressionDict, separators=(',', ':'))
                    self.filterExpressionStringEnc = "filter=" + urllib.parse.quote(
                        json.dumps(filterExpressionDict, separators=(',', ':')))
                    self.filterFlag = True
                    return self.BuildURLSuffix()
        self.SetBad()
        return None

    def SetEmbed(self, awsServiceType):
        embedDictTemplate = {
            "EBS": "read-aws-environment-ebs-volumes-compliance-stats",
            "RDS": "read-aws-environment-rds-resources-compliance-stats",
            "DYNAMODB": "read-aws-environment-dynamodb-tables-compliance-stats",
            "S3": "read-aws-environment-protection-groups-compliance-stats",
            "MSSQL": "read-aws-environment-ec2-mssql-compliance-stats"
        }
        if awsServiceType not in embedDictTemplate.keys():
            self.embedFlag = False
            return False

        if self.queryParmsFlag:
            if embedDictTemplate.get(awsServiceType, None) in self.queryParms.get("sort", []):
                self.embedExpressionString = "embed=" + embedDictTemplate.get(awsServiceType, None)
                self.embedFlag = True
                return self.BuildURLSuffix()
        self.SetBad()
        return None

    def SetSearchAccountId(self, account_id):
        self.SearchAccountIdFlag = True
        self.SearchAccountId = account_id
        #print(f"AccountId {account_id}")

    def SetSearchRegion(self, SearchRegion):
        goodRegions = ["us-east-1", "us-east-2", "us-west-1", "us-west-2"]
        if SearchRegion in goodRegions:
            self.SearchRegionFlag = True
            self.SearchRegion = SearchRegion
        else:
            self.SearchRegionFlag = False

    def SetSearchStatus(self, status):
        #Not sure what good values are, so do not use.
        self.SearchStatusFlag = False

    def SetSearchService(self, AWSService):
        goodServices = ["EBS", "RDS", "DynamoDB"]
        if AWSService in goodServices:
            self.SearchServiceFlag = True
            self.SearchService = AWSService
        else:
            self.SearchRegionFlag = False

# NEXT API

class RestoreEC2(API):
    def __init__(self):
        super(RestoreEC2, self).__init__("003")
        self.id = "003"
        self.filterList = []
        # self.filterExpression = {}
        self.filterExpressionString = ""
        self.filterExpressionStringEnc = ""
        self.limitExpressionString = ""
        self.startExpressionString = ""
        self.embedExpressionString = ""
        self.filterFlag = False
        self.limitFlag = False
        self.startFlag = False
        # self.sortFlag = False
        self.embedFlag = False
        self.limit = 100
        self.start = 1
        self.URLSuffixList = []
        self.URLSuffixListEnc = []
        self.URLSuffixString = ""
        self.URLSuffixStringEnc = ""
        self.HTMLURLSuffSting = ""
        self.typeGet = False
        self.typePost = False
        self.SetPagnation()
        self.GoodRunFlag = True
        self.filterExpression = None
        self.SearchServiceFlag = False
        self.SearchService = None
        self.SearchAccountIdFlag = False
        self.SearchAccountId = None
        self.SearchStatusFlag = False
        self.SearchRegionFlag = False
        self.SearchRegion = None
        self.EnvironmentIdDict = {}
        self.SetPagnation()
        self.KMSKeyNameTarget = ""
        self.KMSKeyFlag = False
        self.NetworkInterfaceMappingFlag = False
        self.NetworkInterfaceSubnetNativeIdTarget = None
        self.NetworkInterfaceSubnetNativeIdFlag = False
        self.NetworkSGListTargetSGListTarget = None
        self.NetworkSGListFlag = False
        self.EC2VpcNativeIdTarget = None
        self.EC2VpcNativeIdFlag = False
        self.EC2SubnetNativeIdTarget = None
        self.EC2SubnetNativeIdFlag = False
        self.IAMInstanceProfileNameTarget = ""
        self.IAMInstanceProfileNameFlag = False
        self.EC2KeyPairNameTarget = ""
        self.EC2KeyPairNameFlag = False
        self.awsAZTarget = None
        self.awsAZFlag = False
        self.TargetEnvironmentId = None
        self.EnvironmentIdFlag = False
        self.TargetFlag = False
        self.LogActivityFlag = False
        self.SetPOST()
        #print(f"RestoreEC2 why apiDICT {apiDICT.get(self.id, {}).get('type', None)}")
        if apiDICT.get(self.id, {}).get('type', None):
            #print(f"apiDICT 01")
            if self.good:
                #print(f"apiDICT 02")
                if apiDICT.get(self.id, {}).get('type', None) == "get":
                    #print(f"apiDICT 03")
                    self.SetGET()
                elif apiDICT.get(self.id, {}).get('type', None) == "post":
                    #print(f"apiDICT 04")
                    self.SetPOST()
                else:
                    #print(f"apiDICT 05")
                    self.SetBad()

    def SetTargetForInstanceRestore(self, target, RestoreType="Simple"):
        EXAMPLE = {
            "account": "",
            "region": "",
            "aws_az": "",
            "iam_instance_profile_name": "",
            "key_pair_name": "",
            "security_group_native_ids": [],
            "subnet_native_id": "",
            "vpc_native_id": "",
            "kms_key_native_id": ""

        }
        if RestoreType == "Simple":
            #print(f" set target {target}")
            if self.SetTargetEnvironmentID(target.get("account", None), target.get("region", None)):
                # Required
                if target.get("aws_az", None):
                    self.SetTargetawsAZ(target.get("aws_az"))
                else:
                    self.good = False
                    return False
                if target.get("subnet_native_id", None):
                    self.SetTargetEC2SubnetNativeId(target.get("subnet_native_id", None))
                    self.SetTargetNetworkInterfaceSubnetNativeId(target.get("subnet_native_id", None))
                else:
                    self.good = False
                    return False
                if target.get("vpc_native_id", None):
                    self.SetTargetEC2VpcNativeId(target.get("vpc_native_id", None))
                else:
                    self.good = False
                    return False
                self.TargetFlag = True
                # Optional
                iam = target.get("iam_instance_profile_name",None)
                #print(f"target iam {iam}")
                if iam:
                    self.SetTargetIAMInstanceProfileName(iam)
                sg = target.get("security_group_native_ids", None)
                #print(f"target sg {sg}")
                if sg:
                    #print("in set sg")
                    self.SetTargetNetworkSGList(sg)
                    self.NetworkSGListFlag = True
                if target.get("key_pair_name", None):
                    self.SetTargetEC2KeyPairName(target.get("key_pair_name"))
                if target.get("kms_key_native_id", None):
                    self.SetTargetKMSKeyName(target.get("kms_key_native_id"))
            else:
                self.good = False
                return False
        elif RestoreType == "Other":
            # Not implemented Yet
            self.good = False
            return False
        else:
            self.good = False
            return False

    def EC2RestoreFromRecord(self,List):
        if len(List) > 0:
            #print(f"Restore List {List}")
            for record in List:
                print(f"record to restore: {record}")
                #Check Expire Time
                if self.CheckExpireTime(record.get('backupRecord',{}).get("SourceExpireTime",None)):
                    runResults = self.runRestoreRecord(record)
                    #print(f"restore results for {record.get("instanceId", None)} {runResults}")
                    if self.LogActivityFlag:
                        pass
                else:
                    print(f"Backup has expired for {record}")
                    pass
            return True
        else:
            self.good = False
            return False

    def CheckExpireTime(self,ExpireTime):
        try:
            expire_date = datetime.fromisoformat(ExpireTime[:-1]).astimezone(timezone.utc)
        except ValueError:
            if self.Debug > 3: print(f"Expire date in invalid format: {ExpireTime}")
            return False
        if expire_date < datetime.now().astimezone(timezone.utc):
            return False
        else:
            #print(f"backup has not expired {ExpireTime}")
            return True

    def EC2RestoreFromFile(self,filename, bucket, prefix, role, AWSSession, region):
        if self.SetupImportFileS3(filename, bucket, prefix, role, AWSSession, region="us-east-2"):
            if self.DataImport():
                #print(f"len of record {len(self.ImportData.get("Records",[]))}")
                for record in self.ImportData.get("Records",[]):
                    #print(f"record to restore: {record}")
                    runResults = self.runRestoreRecord(record)
                    #print(runResults)
                    #print(f"restore results for {record.get("instanceId",None)} {runResults}")
                    if self.LogActivityFlag:
                        pass
                return True
        self.good = False
        return False

    def ParseEC2Tags(self, record, RestoreType="Simple"):
        if RestoreType == "Simple":
            ec2Tags = record.get("backupRecord", {}).get("tags", [{"key": "", "value": ""}])
            return ec2Tags
        elif RestoreType == "AddTag":
            if self.EC2AddTagFlag:
                NewTags = self.AddEC2Tag(record)
                return NewTags
            else:
                self.good = False
                return False
        else:
            self.good = False
            return False

    def ParseVolumesRestoreTarget(self, record, RestoreType="Simple"):
        if RestoreType == "Simple":
            # Simple restore means all default values and aws_az Not target_instance_native_id is used
            if self.awsAZFlag:
                aws_az = self.awsAZTarget
                rsp = self.ParseEBSFromRecordList(record)
                if rsp:
                    ebs_block_device_mappings = rsp
                else:
                    self.good = False
                    return False
                if self.EnvironmentIdFlag:
                    environment_id = self.EnvironmentId
                else:
                    self.good = False
                    return False
                VolumTargetRecord = {
                    "aws_az": aws_az,
                    "ebs_block_device_mappings": ebs_block_device_mappings,
                    "environment_id": environment_id
                }
                return VolumTargetRecord
            else:
                self.good = False
                return False
        elif RestoreType == "Other":
            # NOT IMPLEMENTED YET
            self.good = False
            return False
        else:
            self.good = False
            return False

    def ParseInstanceRestoreTarget(self, record, RestoreType="Simple"):
        # Simple restore means all default values and should_power_on = True
        if RestoreType == "Simple":
            should_power_on = True
            if self.awsAZFlag:
                aws_az = self.awsAZTarget
            else:
                self.good = False
                return False
            rsp = self.ParseEBSFromRecordList(record)
            if rsp:
                ebs_block_device_mappings = rsp
            else:
                self.good = False
                return False
            if self.EnvironmentIdFlag:
                environment_id = self.EnvironmentIdTarget
            else:
                self.good = False
                return False
            ec2Tags = record.get("backupRecord", {}).get("SourceInstanceTags", [])
            ami_native_id = ""
            if self.EC2KeyPairNameFlag:
                key_pair_name = self.EC2KeyPairNameTarget
            else:
                key_pair_name = ""
            rsp = self.ParseNetworkInterfaceRecordList(record)
            if rsp:
                network_interfaces = rsp
            else:
                self.good = False
                return False
            iam_instance_profile_name = None
            if record.get("backupRecord", {}).get("SourceIAMInstanceProfileName", None):
                if self.IAMInstanceProfileNameFlag:
                    iam_instance_profile_name = self.IAMInstanceProfileNameTarget
                else:
                    # record had an instance profile but target does not have one (dont fail)
                    iam_instance_profile_name = ""
                    self.ErrorMsg = "Missing IAM Instance Profile for EC2 restore"
            if self.EC2SubnetNativeIdFlag:
                subnet_native_id = self.EC2SubnetNativeIdTarget
            else:
                self.good = False
                return False
            if self.EC2VpcNativeIdFlag:
                vpc_native_id = self.EC2VpcNativeIdTarget
            else:
                self.good = False
                return False
            instanceRestoreTarget = {
                "should_power_on": should_power_on,
                "aws_az": aws_az,
                "ebs_block_device_mappings": ebs_block_device_mappings,
                "environment_id": environment_id,
                "iam_instance_profile_name": iam_instance_profile_name,
                "ami_native_id": ami_native_id,
                "tags": ec2Tags,
                "key_pair_name": key_pair_name,
                "network_interfaces": network_interfaces,
                "subnet_native_id": subnet_native_id,
                "vpc_native_id": vpc_native_id
            }
            return instanceRestoreTarget

        elif RestoreType == "Other":
            # NOT IMPLEMENTED YET
            self.good = False
            return False
        else:
            self.good = False
            return False

    def ParseNetworkInterfaceRecordList(self, record, RestoreType="Simple"):
        if RestoreType == "Simple":
            NIRecordList = []
            for NIRecord in record.get("backupRecord", {}).get("SourceNetworkInterfaceList", []):
                rsp = self.ParseNetworkInterfaceRecord(NIRecord)
                NIRecordList.append(rsp)
            return NIRecordList
        elif RestoreType == "Other":
            # No other methods supported yet
            return False
        else:
            self.good = False
            return False

    def ParseNetworkInterfaceRecord(self, record, RestoreType="Simple"):
        # Simple restore means using default values, restore default = True and restore from backup = False
        if RestoreType == "Simple":
            #print(f"network interface record: {record}")
            if record.get("security_group_native_ids", []):
                #print("found sg")
                if self.NetworkSGListFlag:
                    security_group_native_ids = self.NetworkSGListTarget
                else:
                    security_group_native_ids = []
            else:
                security_group_native_ids = []
            network_interface_native_id = ""
            if self.NetworkInterfaceSubnetNativeIdFlag:
                subnet_native_id = self.NetworkInterfaceSubnetNativeIdTarget
            else:
                self.good = False
                return False
            device_index = record.get("device_index", None)
            network_interface_native_id = ""
            restore_default = True
            restore_from_backup = False

            NetworkInterfaceTargetRecord = {
                "device_index": device_index,
                "network_interface_native_id": network_interface_native_id,
                "subnet_native_id": subnet_native_id,
                "restore_default": restore_default,
                "restore_from_backup": restore_from_backup,
                "security_group_native_ids": security_group_native_ids
            }
            return NetworkInterfaceTargetRecord

        elif RestoreType == "Mapping":
            if self.NetworkInterfaceMappingFlag:
                # [] = self.NetworkInterfaceMapping(record)
                # NOT IMPLEMENTED YET
                return False
        else:
            return False

    def ParseEBSFromRecordList(self, record, RestoreType="Simple"):
        if RestoreType == "Simple":
            EBSRecordList = []
            for EBSRecord in record.get("backupRecord", {}).get("SourceEBSStorageList", []):
                rsp = self.ParseEBSFromRecord(EBSRecord)
                EBSRecordList.append(rsp)
            return EBSRecordList
        elif RestoreType == "Other":
            # No other methods supported yet
            return False
        else:
            self.good = False
            return False

    def ParseEBSFromRecord(self, record, RestoreType="Simple"):
        #print(f"EBS record {record}")
        if RestoreType == "Simple":
            if record.get("kms_key_native_id", None):
                if self.KMSKeyFlag:
                    kms_key_native_id = self.KMSKeyNameTarget
                else:
                    self.good = False
                    return False
            else:
                kms_key_native_id = ""
            volume_native_id = record.get("volume_native_id", None)
            mount_name = record.get("name", None)
            rec_ebs_tags = record.get("tags", [{"key": "", "value": ""}])
            #print(f"ebs tag {rec_ebs_tags}")
            if len(rec_ebs_tags) < 1:
                #print("ebs correct tags")
                rec_ebs_tags = [{"key": "Name", "value": ""}]
                ebsTags = rec_ebs_tags
            else:
                ebsTags = record.get("tags", [{"key": "", "value": ""}])
            EBSTargetRecord = {
                "volume_native_id": volume_native_id,
                "kms_key_native_id": kms_key_native_id,
                "name": mount_name,
                "tags": ebsTags
            }
            return EBSTargetRecord
        elif RestoreType == "AddTag":
            if self.EBSAddTagFlag:
                NewTags = self.AddEBSTag(record)
                if record.get("kms_key_native_id", None):
                    if self.KMSKeyFlag:
                        kms_key_native_id = self.KMSKeyNameTarget
                    else:
                        self.good = False
                        return False
                else:
                    kms_key_native_id = None
                volume_native_id = record.get("volume_native_id", None)
                mount_name = record.get("name", None)
                ebsTags = record.get("tags", [{"key": "", "value": ""}])
                EBSTargetRecord = {
                    "volume_native_id": volume_native_id,
                    "kms_key_native_id": kms_key_native_id,
                    "name": mount_name,
                    "tags": NewTags
                }
                return EBSTargetRecord
            else:
                return False
        elif RestoreType == "EBSMapping":
            # Not Implemented Yet
            return False
            # if self.EBSMappingFlag:
            #    [NewMountName,NewKMSKey,NewTags] = self.EBSMapping(record)
            #    if NewKMSKey:
            #        kms_key_native_id = NewKMSKey
            #    else:
            #        kms_key_native_id = None
            #    volume_native_id = record.get("backupRecord",{}).get("SourceEBSStorageList",{}).get("volume_native_id",None)
            #    mount_name = NewMountName
            #    ebsTags = NewTags
            #    EBSTargetRecord = {
            #        "volume_native_id":volume_native_id,
            #        "kms_key_native_id":kms_key_native_id,
            #        "name":mount_name,
            #        "tags": NewTags
            #    }
            #    return EBSTargetRecord
            # else:
            #    return False
        else:
            return False

    def SetEBSBlockMapping(self, InputBlockMapping):
        # Not Implemented Yet
        return False

    def SetTargetKMSKeyName(self, value):
        self.KMSKeyNameTarget = value
        self.KMSKeyFlag = True

    def ClearTargetKMSKeyName(self):
        self.KMSKeyNameTarget = None
        self.KMSKeyFlag = False

    def SetTargetNetworkInterfaceSubnetNativeId(self, value):
        self.NetworkInterfaceSubnetNativeIdTarget = value
        self.NetworkInterfaceSubnetNativeIdFlag = True

    def ClearTargetNetworkInterfaceSubnetNativeId(self):
        self.NetworkInterfaceSubnetNativeIdTarget = None
        self.NetworkInterfaceSubnetNativeIdFlag = False

    def SetTargetNetworkSGList(self, value):
        self.NetworkSGListTarget = value
        self.NetworkSGFlag = True

    def ClearTargetNetworkSGList(self):
        self.NetworkSGListTarget = []
        self.NetworkSGFlag = False

    def SetTargetEC2VpcNativeId(self, value):
        self.EC2VpcNativeIdTarget = value
        self.EC2VpcNativeIdFlag = True

    def ClearTargetEC2VpcNativeId(self):
        self.EC2VpcNativeIdTarget = None
        self.EC2VpcNativeIdFlag = False

    def SetTargetEC2SubnetNativeId(self, value):
        self.EC2SubnetNativeIdTarget = value
        self.EC2SubnetNativeIdFlag = True

    def ClearTargetEC2SubnetNativeId(self):
        self.EC2SubnetNativeIdTarget = None
        self.EC2SubnetNativeIdFlag = False

    def SetTargetIAMInstanceProfileName(self, value):
        self.IAMInstanceProfileNameTarget = value
        self.IAMInstanceProfileNameFlag = True

    def ClearTargetIAMInstanceProfileName(self):
        self.IAMInstanceProfileNameTarget = None
        self.IAMInstanceProfileNameFlag = False

    def SetTargetEC2KeyPairName(self, value):
        self.EC2KeyPairNameTarget = value
        self.EC2KeyPairNameFlag = True

    def ClearTargetEC2KeyPairName(self):
        self.EC2KeyPairNameTarget = None
        self.EC2KeyPairNameFlag = False

    def SetTargetawsAZ(self, value):
        self.awsAZTarget = value
        self.awsAZFlag = True

    def ClearTargetawsAZ(self):
        self.awsAZTarget = None
        self.awsAZFlag = False

    def SetBackupId(self, record):
        if record.get("backupRecord", {}).get("SourceBackupId", None):
            self.BackupId = record.get("backupRecord", {}).get("SourceBackupId", None)
            self.BackupIdFlag = True
            return self.BackupId

        else:
            self.good = False
        return False


    def ClearBackupId(self):
        self.awsAZTarget = None
        self.awsAZFlag = False


    def SetTargetEnvironmentID(self, account, region):
        if self.SetAWSAccountId(account) and self.SetAWSRegion(region):
            EnvIdAPI = EnvironmentId()
            EnvIdAPI.SetToken(self.token)
            EnvIdAPI.SetSearchAccountId(self.AWSAccountId)
            EnvIdAPI.SetSearchRegion(self.AWSRegion)
            if EnvIdAPI.runAll():
                rsp = EnvIdAPI.EnvironmentIdParseResults()
                del EnvIdAPI
                if rsp:
                    self.EnvironmentIdTarget = rsp
                    self.EnvironmentIdFlag = True
                    return True
        del EnvIdAPI
        self.good = False
        return False


    def ClearTargetEnvironmentId(self):
        self.EnvironmentIdTarget = None
        self.EnvironmentIdFlag = False



    def AddEBSTag(self, record):
        # Not Implemented Yet
        return False


    def SetPayload(self, record, RestoreType="EC2"):
        if RestoreType == "EC2":
            if self.TargetFlag:
                BackupId = self.SetBackupId(record)
                EC2RestoreTarget = self.ParseInstanceRestoreTarget(record)

                if BackupId and EC2RestoreTarget:
                    payload = {
                        "source": {"backup_id": BackupId},
                        "target": {"instance_restore_target": EC2RestoreTarget}
                    }
                    self.payload = payload
                    self.payloadFlag = True
                    return True
        elif RestoreType == "RDS":
            # Not implemente yet
            return False
        elif RestoreType == "AMI":
            # Not implemente yet
            return False

        self.good = False
        return False


    def runRestoreRecord(self, record):
        if self.good:
            if self.SetPayload(record):
                result = self.ExecAPI()

                return result
        else:
            return False

    def EnvironmentIdParseResults(self, ParseType="ID"):
        ExampleParmsList = [
            "ID :BackupIds & InstanceIds & TimeStamp",
            "Restore :Parameters Needed for EC2 Restore",
            "Count : Number of Instances",
            "All : All Data"
        ]
        #print(self.EnvironmentIdDict)
        if ParseType == "ID":
            if self.EnvironmentIdDict:
                if len(self.EnvironmentIdDict.keys()) > 1:
                    return False
                else:
                    for key in self.EnvironmentIdDict.keys():
                        return key
            else:
                return False
        elif ParseType == "ALL":
            if self.EnvironmentIdDict:
                return self.EnvironmentIdDict
            else:
                return False
        return False

    def SetPageSize(self, x):
        if self.queryParmsFlag:
            if "limit" in self.queryParms.keys():
                self.limit = x
                self.limitExpressionString = "limit=" + str(self.limit)
                self.limitFlag = True
                return self.BuildURLSuffix()
        self.SetBad()
        return None


    def BuildURLSuffix(self):
        self.URLSuffixList = []
        if self.good:
            if self.filterFlag:
                self.URLSuffixList.append(self.filterExpressionStringEnc)

            if self.embedFlag:
                self.URLSuffixList.append(self.sortExpressionString)

            if self.limitFlag:
                self.URLSuffixList.append(self.limitExpressionString)

            if self.startFlag:
                self.URLSuffixList.append(self.startExpressionString)

            self.URLSuffString = "?" + "&".join(self.URLSuffixList)
            String = self.URLSuffString
            # #print(String)
            self.SetURL(String)
            return self.URLSuffString

#NEXT API

class EBSBackupList(API):
    def __init__(self):
        super(EBSBackupList, self).__init__("004")
        self.id = "001"
        self.filterList = []
        self.filterExpression = {}
        self.filterExpressionString = ""
        self.filterExpressionStringEnc = ""
        self.limitExpressionString = ""
        self.startExpressionString = ""
        self.sortExpressionString = ""
        self.filterFlag = False
        self.limitFlag = False
        self.startFlag = False
        self.sortFlag = False
        self.limit = 100
        self.start = 1
        self.URLSuffixList = []
        self.URLSuffixListEnc = []
        self.URLSuffixString = ""
        self.URLSuffixStringEnc = ""
        self.HTMLURLSuffSting = ""
        self.typeGet = False
        self.typePost = False
        self.SetPagnation()
        self.GoodRunFlag = True
        self.filterExpression = None
        self.startDayTimeStamp = None
        self.SearchVolumeId = None
        self.searchType = None
        self.searchStartDay = 0
        self.searchEndDay = 10
        self.TagNameMatch = ""
        self.TagValueMatch = ""
        self.SeachInstnaceId = ""
        self.SearchVolumeIdFlag = False
        # self.filterExpression = "$lte"
        self.StartHour = "22"
        self.StartMin = "58"
        self.StartSec = "58"
        self.endDate = None
        self.SetSort("-start_timestamp")
        self.CurrentEbsVolumeIdTimeStamp = {}
        self.CurrentEbsVolumeInfo = {}
        self.SetPagnation()
        #print(f"RestoreEC2 why apiDICT {apiDICT.get(self.id, {}).get('type', None)}")
        if apiDICT.get(self.id, {}).get('type', None):
            #print(f"apiDICT 01")
            if self.good:
                #print(f"apiDICT 02")
                if apiDICT.get(self.id, {}).get('type', None) == "get":
                    #print(f"apiDICT 03")
                    self.SetGET()
                elif apiDICT.get(self.id, {}).get('type', None) == "post":
                    #print(f"apiDICT 04")
                    self.SetPOST()
                else:
                    #print(f"apiDICT 05")
                    self.SetBad()

    def runAll(self):
        if self.searchType:
            DayStartDelta = self.searchStartDay
            DayEndDelta = self.searchEndDay
            #print(f"the delta start end {DayStartDelta} {DayEndDelta}")
            if self.searchType == "After":
                if DayStartDelta > DayEndDelta:
                    self.ErrorMsg = "Search Start day is older then search end day"
                    return False
                today = datetime.now().astimezone(timezone.utc)
                startDelta = timedelta(days=DayStartDelta)
                endDelta = timedelta(days=DayEndDelta)
                startDate = today - startDelta
                self.endDate = today - endDelta
                # #print(startDate)
                if startDate.year < 10:
                    startDateYear = "0" + str(startDate.year)
                else:
                    startDateYear = str(startDate.year)
                if startDate.month < 10:
                    startDateMonth = "0" + str(startDate.month)
                else:
                    startDateMonth = str(startDate.month)
                if startDate.day < 10:
                    startDateDay = "0" + str(startDate.day)
                else:
                    startDateDay = str(startDate.day)
                self.startDayTimeStamp = f"{startDateYear}-{startDateMonth}-{startDateDay}T{self.StartHour}:{self.StartMin}:{self.StartSec}Z"
            elif self.searchType == "Before":
                today = datetime.now().astimezone(timezone.utc)
                endDelta = timedelta(days=DayEndDelta)
                endDate = today - endDelta
                # #print(startDate)
                if endDate.year < 10:
                    endDateYear = "0" + str(endDate.year)
                else:
                    endDateYear = str(endDate.year)
                if endDate.month < 10:
                    endDateMonth = "0" + str(endDate.month)
                else:
                    endDateMonth = str(endDate.month)
                if endDate.day < 10:
                    endDateDay = "0" + str(endDate.day)
                else:
                    endDateDay = str(endDate.day)
                # startDateMonth = str(startDate.month)
                # startDateDay = str(startDate.day)
                self.startDayTimeStamp = f"{endDateYear}-{endDateMonth}-{endDateDay}T{self.StartHour}:{self.StartMin}:{self.StartSec}Z"
            self.SetFilter("start_timestamp", self.filterExpression, self.startDayTimeStamp)
        if self.SearchVolumeIdFlag:
            self.SetFilter("volume_id", "$eq", self.SearchVolumeId)
        self.Results = []
        FirstResults = self.ExecAPI()
        if self.good:
            items = FirstResults.get("_embedded", {}).get("items", {})
            for i in items:
                check = self.PassCheck(i)
                if check:
                    self.CurrentEbsVolumeInfo[check] = i
        else:
            return False
        if self.total_pages_count:
            if self.total_pages_count > 1:
                for i in range(2, self.total_pages_count):
                    self.SetPageStart(i)
                    NextResults = self.ExecAPI()
                    if self.good:
                        items = NextResults.get("_embedded", {}).get("items", {})
                        for i in items:
                            check = self.PassCheck(i)
                            if check:
                                self.CurrentEbsVolumeInfo[check] = i
                    else:
                        return False
                    # #print(f"read page {i}")
        return len(self.CurrentEbsVolumeInfo)

    def PassCheck(self, response):
        awsRegion = response.get("aws_region", None)
        awsAccountId = response.get("account_native_id", None)
        if not (awsRegion == self.AWSRegion and awsAccountId == self.AWSAccountId):
            return False
        if self.AWSTagFlag:
            tags = response.get("tags", None)
            FoundTag = False
            for tag in tags:
                if tag.get("key", None) == self.AWSTagKey and tag.get("value", None) == self.AWSTagValue:
                    FoundTag = True
            if not FoundTag:
                return False
        time_stamp = response.get("start_timestamp", None)
        clumio_volume_id = response.get("volume_id", None)
        new_date = datetime.fromisoformat(time_stamp[:-1]).astimezone(timezone.utc)
        if self.searchType == "After":
            # new_date = datetime.fromisoformat(time_stamp[:-1]).astimezone(timezone.utc)
            if self.CurrentEbsVolumeIdTimeStamp.get(clumio_volume_id, None):
                if new_date > self.CurrentEbsVolumeIdTimeStamp.get(clumio_volume_id, None):
                    self.CurrentEbsVolumeIdTimeStamp[clumio_volume_id] = new_date
                    return clumio_volume_id
                else:
                    return False
            else:
                if new_date > self.endDate:
                    return clumio_volume_id
                else:
                    return False
        else:
            if self.CurrentEbsVolumeIdTimeStamp.get(clumio_volume_id, None):
                if new_date > self.CurrentEbsVolumeIdTimeStamp.get(clumio_volume_id, None):
                    self.CurrentEbsVolumeIdTimeStamp[clumio_volume_id] = new_date
                    return clumio_volume_id
                else:
                    return False
            else:
                self.CurrentEbsVolumeIdTimeStamp[clumio_volume_id] = new_date
                return clumio_volume_id

    def EBSParseResults(self, ParseType):
        ExampleParmsList = [
            "ID :BackupIds & VolumeIds & TimeStamp",
            "Restore :Parameters Needed for EC2 Restore",
            "Count : Number of Volumes",
            "All : All Data"
        ]
        records = []
        if ParseType == "ID":
            for vol in self.CurrentEbsVolumeInfo.keys():
                rec = {"IDRecord": [self.CurrentEbsVolumeInfo[vol].get("volume_native_id", None),
                                    self.CurrentEbsVolumeInfo[vol].get("id", None),
                                    self.CurrentEbsVolumeInfo[vol].get("start_timestamp", None)]}
                records.append(rec)
            ClumioResourceListDict = {"Records": records}
            if self.DumpToFileFlag:
                # #print("in the dumpining 01")
                if not self.DataDump(ClumioResourceListDict):
                    return False
            return ClumioResourceListDict
        elif ParseType == "ALL":
            for vol in self.CurrentEbsVolumeInfo.keys():
                rec = {"item": self.CurrentEbsVolumeInfo[vol]}
                records.append(rec)
            ClumioResourceListDict = {"Records": records}
            if self.DumpToFileFlag:
                # #print("in the dumpining 01")
                if not self.DataDump(ClumioResourceListDict):
                    return False
            return ClumioResourceListDict
        elif ParseType == "Restore":

            for vol in self.CurrentEbsVolumeInfo.keys():
                if self.Debug > 2: print(f"volume record {self.CurrentEbsVolumeInfo[vol]}")
                if self.CurrentEbsVolumeInfo[vol].get("is_encrypted"):
                    isEncrypted = True
                else:
                    isEncrypted = False

                rec = {"volumeId": self.CurrentEbsVolumeInfo[vol].get("volume_native_id", None),
                       "backupRecord": {
                           "SourceBackupId": self.CurrentEbsVolumeInfo[vol].get("id", None),
                           "SourceVolumeId": self.CurrentEbsVolumeInfo[vol].get("volume_native_id",None),
                           "SourceVolumeTags": self.CurrentEbsVolumeInfo[vol].get("tags", []),
                           "SourceEncryptedFlag": isEncrypted,
                           "SourceAZ": self.CurrentEbsVolumeInfo[vol].get("aws_az", None),
                           "SourceKMS": self.CurrentEbsVolumeInfo[vol].get("kms_key_native_id", None),
                           "SourceExpireTime": self.CurrentEbsVolumeInfo[vol].get("expiration_timestamp", None),
                            }
                       }
                records.append(rec)
            ClumioResourceListDict = {"Records": records}
            if self.DumpToFileFlag:
                # #print("in the dumpining 01")
                if not self.DataDump(ClumioResourceListDict):
                    return False
            return ClumioResourceListDict
        return {}

    def EBSSearchByTag(self, Key, Value):
        self.SetAWSTagKey(Key)
        self.SetAWSTagValue(Value)

    def SetPageSize(self, x):
        if self.queryParmsFlag:
            if "limit" in self.queryParms.keys():
                self.limit = x
                self.limitExpressionString = "limit=" + str(self.limit)
                self.limitFlag = True
                return self.BuildURLSuffix()
        self.SetBad()
        return None

    def SetPageStart(self, x):
        if self.queryParmsFlag:
            if "start" in self.queryParms.keys():
                self.start = x
                self.startExpressionString = "start=" + str(self.start)
                self.startFlag = True
                return self.BuildURLSuffix()
        self.SetBad()
        return None

    def BuildURLSuffix(self):
        self.URLSuffixList = []
        if self.good:
            if self.filterFlag:
                self.URLSuffixList.append(self.filterExpressionStringEnc)

            if self.sortFlag:
                self.URLSuffixList.append(self.sortExpressionString)

            if self.limitFlag:
                self.URLSuffixList.append(self.limitExpressionString)

            if self.startFlag:
                self.URLSuffixList.append(self.startExpressionString)

            self.URLSuffString = "?" + "&".join(self.URLSuffixList)
            String = self.URLSuffString
            # #print(String)
            self.SetURL(String)
            return self.URLSuffString

    def SetFilter(self, filterName, filterExpression, filterValue):
        filterExpressionDict = {}
        #print(f"setFilter 01 {filterName}")
        if self.queryParmsFlag:
            #print("setFilter 02")
            if filterName in self.queryParms.get("filter", {}).keys():
                #print("setFilter 03")
                if filterExpression in self.queryParms.get("filter", {}).get(filterName, []):
                    #print("setFilter 04")
                    self.filterList.append([filterName, filterExpression, filterValue])
                    for i in self.filterList:
                        ##print(f"in SetFilter 05 {i}")
                        filterExpressionDict[i[0]] = {i[1]: i[2]}
                    self.filterExpressionString = "filter=" + json.dumps(filterExpressionDict, separators=(',', ':'))
                    self.filterExpressionStringEnc = "filter=" + urllib.parse.quote(
                        json.dumps(filterExpressionDict, separators=(',', ':')))
                    self.filterFlag = True
                    return self.BuildURLSuffix()
        self.SetBad()
        return None

    def SetSort(self, sortName):

        if self.queryParmsFlag:
            if sortName in self.queryParms.get("sort", []):
                self.sortExpressionString = "sort=" + sortName
                self.sortFlag = True
                return self.BuildURLSuffix()
        self.SetBad()
        return None

    def SetSearchVolumeId(self, volume_id):
        self.SearchVolumeIdFlag = True
        self.SearchVolumeId = volume_id

    def SetSearchTimeFrameBeforeAfter(self, searchType):
        self.searchType = searchType
        if self.searchType == "Before":
            self.filterExpression = "$gt"
            self.StartHour = "00"
            self.StartMin = "00"
            self.StartSec = "00"
        elif self.searchType == "After":
            self.filterExpression = "$lte"
            self.StartHour = "23"
            self.StartMin = "59"
            self.StartSec = "59"
        else:
            self.GoodRunFlag = False

    def SetSearchStartDay(self, startDay):
        try:
            int(startDay)
            self.searchStartDay = startDay
        except ValueError:
            return False
        return True

    def SetSearchEndDay(self, endDay):
        try:
            int(endDay)
            self.searchEndDay = endDay
        except ValueError:
            return False
        return True


#NEW API

class RestoreEBS(API):
    def __init__(self):
        super(RestoreEBS, self).__init__("005")
        self.id = "003"
        self.filterList = []
        # self.filterExpression = {}
        self.filterExpressionString = ""
        self.filterExpressionStringEnc = ""
        self.limitExpressionString = ""
        self.startExpressionString = ""
        self.embedExpressionString = ""
        self.filterFlag = False
        self.limitFlag = False
        self.startFlag = False
        # self.sortFlag = False
        self.embedFlag = False
        self.limit = 100
        self.start = 1
        self.URLSuffixList = []
        self.URLSuffixListEnc = []
        self.URLSuffixString = ""
        self.URLSuffixStringEnc = ""
        self.HTMLURLSuffSting = ""
        self.typeGet = False
        self.typePost = False
        self.SetPagnation()
        self.GoodRunFlag = True
        self.filterExpression = None
        self.SearchServiceFlag = False
        self.SearchService = None
        self.SearchAccountIdFlag = False
        self.SearchAccountId = None
        self.SearchStatusFlag = False
        self.SearchRegionFlag = False
        self.SearchRegion = None
        self.EnvironmentIdDict = {}
        self.SetPagnation()
        self.KMSKeyNameTarget = ""
        self.KMSKeyFlag = False
        self.AllowedVolumeTypes = ["gp2", "gp3"]
        #self.NetworkInterfaceMappingFlag = False
        #self.NetworkInterfaceSubnetNativeIdTarget = None
        #self.NetworkInterfaceSubnetNativeIdFlag = False
        #self.NetworkSGListTargetSGListTarget = None
        #self.NetworkSGListFlag = False
        #self.EC2VpcNativeIdTarget = None
        #self.EC2VpcNativeIdFlag = False
        #self.EC2SubnetNativeIdTarget = None
        #self.EC2SubnetNativeIdFlag = False
        #self.IAMInstanceProfileNameTarget = ""
        #self.IAMInstanceProfileNameFlag = False
        #self.EC2KeyPairNameTarget = ""
        #self.EC2KeyPairNameFlag = False
        self.awsAZTarget = None
        self.awsAZFlag = False
        self.TargetEnvironmentId = None
        self.EnvironmentIdFlag = False
        self.TargetFlag = False
        self.LogActivityFlag = False
        self.IOPSTarget = None
        self.IOPSFlag = False
        self.VolumeTypeTarget = None
        self.VolumeTypeFlag = False
        self.SetPOST()
        #print(f"RestoreEC2 why apiDICT {apiDICT.get(self.id, {}).get('type', None)}")
        if apiDICT.get(self.id, {}).get('type', None):
            #print(f"apiDICT 01")
            if self.good:
                #print(f"apiDICT 02")
                if apiDICT.get(self.id, {}).get('type', None) == "get":
                    #print(f"apiDICT 03")
                    self.SetGET()
                elif apiDICT.get(self.id, {}).get('type', None) == "post":
                    #print(f"apiDICT 04")
                    self.SetPOST()
                else:
                    #print(f"apiDICT 05")
                    self.SetBad()


    def SetTargetForEBSRestore(self, target, RestoreType="Simple"):
        EXAMPLE = {
            "account": "",
            "region": "",
            "aws_az": "",
            "iops": None,
            "kms_key_native_id": "",
            "volume_type": None

        }
        if self.Debug > 1: print(f"SetTargetForEBSRestore - Good value {self.good}")
        if RestoreType == "Simple":
            #print(f" set target {target}")
            if self.Debug > 3: print(f"SetTargetForEBSRestore target: {target}, RestoreType: {RestoreType} ")
            if self.SetTargetEnvironmentID(target.get("account", None), target.get("region", None)):
                # Required
                if target.get("aws_az", None):
                    self.SetTargetawsAZ(target.get("aws_az"))
                else:
                    if self.Debug > 3: print("SetTargetForEBSRestore could not set az ")
                    self.good = False
                    return False
                self.TargetFlag = True

                # Optional

                iops = target.get("iops",None)
                if iops:
                    self.SetTargetIOPS(iops)

                volume_type = target.get("volume_type", None)
                if volume_type:
                    self.SetTargetVolumeType(volume_type)


                kms_key_native_id = target.get("kms_key_native_id", None)
                if kms_key_native_id:
                    self.SetTargetKMSKeyName(kms_key_native_id)
                    self.KMSKeyFlag = True
                if self.Debug > 4: print("SetTargetForEBSRestore TargetValuesSet ")

            else:
                if self.Debug > 3: print("SetTargetForEBSRestore could not set target account and region ")
                self.good = False
                return False
        elif RestoreType == "Other":

            self.good = False
            return False
        else:
            self.good = False
            return False

    def EBSRestoreFromRecord(self,List,RestoreType="Simple"):
        if self.Debug > 1: print(f"EBSRestoreFromRecord - Good value {self.good}")
        if len(List) > 0:
            #print(f"Restore List {List}")
            for record in List:
                if self.Debug > 1: print(f"record to restore: {record}")
                #Check Expire Time
                if self.CheckExpireTime(record.get('backupRecord',{}).get("SourceExpireTime",None)):
                    runResults = self.runRestoreRecord(record,RestoreType)
                    #if self.Debug > 1: print(f"restore results for {record.get("volumeId", None)} {runResults}")
                    if self.LogActivityFlag:
                        pass
                else:
                    if self.Debug > 3:
                        print(f"Backup has expired for {record}")
                    pass
            return True
        else:
            self.good = False
            if self.Debug > 3:
                print("EBS List has no records to restore")
            return False

    def CheckExpireTime(self,ExpireTime):
        try:
            expire_date = datetime.fromisoformat(ExpireTime[:-1]).astimezone(timezone.utc)
        except ValueError:
            if self.Debug > 3: print(f"Expire date in invalid format: {ExpireTime}")
            return False
        if expire_date < datetime.now().astimezone(timezone.utc):
            if self.Debug > 3: print(f"Expired: {ExpireTime}")
            return False
        else:
            if self.Debug > 3: print(f"backup has not expired {ExpireTime}")
            return True

    def EBSRestoreFromFile(self,filename, bucket, prefix, role, AWSSession, region):
        if self.SetupImportFileS3(filename, bucket, prefix, role, AWSSession, region="us-east-2"):
            if self.DataImport():
                #print(f"len of record {len(self.ImportData.get("Records",[]))}")
                for record in self.ImportData.get("Records",[]):
                    #print(f"record to restore: {record}")
                    runResults = self.runRestoreRecord(record)
                    if self.Debug > 4: print(f"EBSRestoreFromFile resutls {runResults}")
                    #print(f"restore results for {record.get("instanceId",None)} {runResults}")
                    if self.LogActivityFlag:
                        pass
                return True
        self.good = False
        return False


    def ParseVolumesRestoreTarget(self, record, RestoreType="Simple"):
        if RestoreType == "Simple":
            # Simple restore means all default values and aws_az Not target_instance_native_id is used
            if self.awsAZFlag:
                aws_az = self.awsAZTarget
                rsp = self.ParseEBSFromRecordList(record)
                if rsp:
                    ebs_block_device_mappings = rsp
                else:
                    self.good = False
                    return False
                if self.EnvironmentIdFlag:
                    environment_id = self.EnvironmentId
                else:
                    self.good = False
                    return False
                VolumTargetRecord = {
                    "aws_az": aws_az,
                    "ebs_block_device_mappings": ebs_block_device_mappings,
                    "environment_id": environment_id
                }
                return VolumTargetRecord
            else:
                self.good = False
                return False
        elif RestoreType == "Other":
            # NOT IMPLEMENTED YET
            self.good = False
            return False
        else:
            self.good = False
            return False


    def ParseEBSRestoreTarget(self, record, RestoreType="Simple"):
        # Simple restore means all default values and should_power_on = True
        if RestoreType == "Simple":
            if self.awsAZFlag:
                aws_az = self.awsAZTarget
            else:
                self.good = False
                return False
            if self.EnvironmentIdFlag:
                environment_id = self.EnvironmentIdTarget
            else:
                self.good = False
                return False
            ebsTags = record.get("backupRecord", {}).get("SourceVolumeTags", [])
            volumeRestoreTarget = {
                "aws_az": aws_az,
                "environment_id": environment_id,
                "tags": ebsTags
            }
            if record.get("backupRecord", {}).get("SourceEncryptedFlag"):
                if self.KMSKeyFlag:
                    kms_key_native_id = self.KMSKeyNameTarget
                    volumeRestoreTarget["kms_key_native_id"] = kms_key_native_id
                else:
                    if self.Debug > 3: print(f"EBS Restore requires KMS, but none provided in target {record} ")
                    self.good = False
                    return False
            if self.IOPSFlag:
                iops = self.IOPSTarget
                volumeRestoreTarget["iops"] = iops
            if self.VolumeTypeFlag:
                type = self.VolumeTypeTarget
                volumeRestoreTarget["type"] = type

            return volumeRestoreTarget
        elif RestoreType == "AddSourceVolumeTag":
            volId = record.get("backupRecord", {}).get("SourceVolumeId", None)
            if volId:
                newTag = {"key": "OrgVolumeId", "value": volId}
            else:
                if self.Debug > 3: print(f"No Source Volume Id found {record} ")
                self.good = False
                return False
            if self.awsAZFlag:
                aws_az = self.awsAZTarget
            else:
                self.good = False
                return False
            if self.EnvironmentIdFlag:
                environment_id = self.EnvironmentIdTarget
            else:
                self.good = False
                return False
            ebsTags = record.get("backupRecord", {}).get("SourceVolumeTags", [])
            ebsTags.append(newTag)
            volumeRestoreTarget = {
                "aws_az": aws_az,
                "environment_id": environment_id,
                "tags": ebsTags
            }
            if record.get("backupRecord", {}).get("SourceEncryptedFlag"):
                if self.KMSKeyFlag:
                    kms_key_native_id = self.KMSKeyNameTarget
                    volumeRestoreTarget["kms_key_native_id"] = kms_key_native_id
                else:
                    if self.Debug > 3: print(f"EBS Restore requires KMS, but none provided in target {record} ")
                    self.good = False
                    return False
            if self.IOPSFlag:
                iops = self.IOPSTarget
                volumeRestoreTarget["iops"] = iops
            if self.VolumeTypeFlag:
                type = self.VolumeTypeTarget
                volumeRestoreTarget["type"] = type

            return volumeRestoreTarget

        elif RestoreType == "Other":
            # NOT IMPLEMENTED YET
            self.good = False
            return False
        else:
            self.good = False
            return False




    def SetTargetIOPS(self, value):
        self.IOPSTarget = value
        self.IOPSFlag = True

    def ClearTargetIOPS(self):
        self.IOPSTarget = None
        self.IOPSFlag = False

    def SetTargetVolumeType(self, value):
        if value in self.AllowedVolumeTypes:
            self.VolumeTypeTarget = value
            self.VolumeTypeFlag = True
        else:
            self.VolumeTypeTarget = None
            self.VolumeTypeFlag = False

    def ClearTargetVolumeType(self):
        self.VolumeTypeTarget = None
        self.VolumeTypeFlag = False


    def SetTargetKMSKeyName(self, value):
        self.KMSKeyNameTarget = value
        self.KMSKeyFlag = True

    def ClearTargetKMSKeyName(self):
        self.KMSKeyNameTarget = None
        self.KMSKeyFlag = False

    def SetTargetawsAZ(self, value):
        self.awsAZTarget = value
        self.awsAZFlag = True

    def ClearTargetawsAZ(self):
        self.awsAZTarget = None
        self.awsAZFlag = False

    def SetBackupId(self, record):
        if record.get("backupRecord", {}).get("SourceBackupId", None):
            self.BackupId = record.get("backupRecord", {}).get("SourceBackupId", None)
            self.BackupIdFlag = True
            return self.BackupId

        else:
            self.good = False
        return False


    def ClearBackupId(self):
        self.awsAZTarget = None
        self.awsAZFlag = False


    def SetTargetEnvironmentID(self, account, region):
        if self.SetAWSAccountId(account) and self.SetAWSRegion(region):
            EnvIdAPI = EnvironmentId()
            EnvIdAPI.SetToken(self.token)
            EnvIdAPI.SetSearchAccountId(self.AWSAccountId)
            EnvIdAPI.SetSearchRegion(self.AWSRegion)
            if EnvIdAPI.runAll():
                rsp = EnvIdAPI.EnvironmentIdParseResults()
                del EnvIdAPI
                if rsp:
                    self.EnvironmentIdTarget = rsp
                    self.EnvironmentIdFlag = True
                    return True
        del EnvIdAPI
        self.good = False
        return False


    def ClearTargetEnvironmentId(self):
        self.EnvironmentIdTarget = None
        self.EnvironmentIdFlag = False



    def SetPayload(self, record, RestoreType="Simple"):
        if RestoreType == "Simple":
            if self.TargetFlag:
                BackupId = self.SetBackupId(record)
                EBSRestoreTarget = self.ParseEBSRestoreTarget(record)

                if BackupId and EBSRestoreTarget:
                    payload = {
                        "source": {"backup_id": BackupId},
                        "target": EBSRestoreTarget
                    }
                    self.payload = payload
                    self.payloadFlag = True
                    return True
        elif RestoreType == "AddSourceVolumeTag":
            # Add a Tag to the volume with the source volume id
            if self.TargetFlag:
                BackupId = self.SetBackupId(record)
                EBSRestoreTarget = self.ParseEBSRestoreTarget(record,"AddSourceVolumeTag")

                if BackupId and EBSRestoreTarget:
                    payload = {
                        "source": {"backup_id": BackupId},
                        "target": EBSRestoreTarget
                    }
                    self.payload = payload
                    self.payloadFlag = True
                    return True
            return False

        self.good = False
        return False


    def runRestoreRecord(self, record,RestoreType="Simple"):
        if RestoreType == "Simple":
            if self.good:
                if self.Debug > 3: print(f"runRestoreRecord -process payload {record} ")
                if self.SetPayload(record):
                    result = self.ExecAPI()

                    return result
            else:
                if self.Debug > 3: print("runRestoreRecord good not set ")
                return False
        elif RestoreType == "AddSourceVolumeTag":
            if self.good:
                if self.SetPayload(record,"AddSourceVolumeTag"):
                    result = self.ExecAPI()

                    return result
            else:
                return False

    def EnvironmentIdParseResults(self, ParseType="ID"):
        #ExampleParmsList = [
        #    "ID :BackupIds & InstanceIds & TimeStamp",
        #    "Restore :Parameters Needed for EC2 Restore",
        #    "Count : Number of Instances",
        #    "All : All Data"
        #]

        if ParseType == "ID":
            if self.EnvironmentIdDict:
                if len(self.EnvironmentIdDict.keys()) > 1:
                    return False
                else:
                    for key in self.EnvironmentIdDict.keys():
                        return key
            else:
                return False
        elif ParseType == "ALL":
            if self.EnvironmentIdDict:
                return self.EnvironmentIdDict
            else:
                return False
        return False


class ListEC2Instance(API):
    def __init__(self):
        super(ListEC2Instance, self).__init__("006")
        self.id = "006"
        self.filter_list = []
        self.filter_expression_string = ""
        self.filter_expression_string_encoded = ""
        self.limit_expression_string = ""
        self.start_expression_string = ""

        self.limit_flag = False
        self.start_flag = False
        self.limit = 100
        self.start = 1
        self.url_suffix_list = []

        self.url_suffix_string = ""
        self.clumio_org_id = None
        self.clumio_org_id_flag = False

        self.SetPagnation()
        self.aws_vpc_id = None
        self.aws_vpc_id_flag = False
        self.aws_subnet_id = None
        self.aws_subnet_id_flag = False
        self.retention_units = None
        self.retention_value = 0
        self.retention_flag = False
        self.clumio_environment_id = None
        self.clumio_environment_id_flag = False
        self.search_filter_flag = False
        self.search_filters = [
            {"name": "environment_id", "value": None, "type": None, "flag": False},
            {"name": "name", "value": None, "type": None, "flag": False},
            {"name": "instance_native_id", "value": None, "type": None, "flag": False},
            {"name": "account_native_id", "value": None, "type": None, "flag": False},
            {"name": "compliance_status", "value": None, "type": None, "flag": False},
            {"name": "protection_status", "value": None, "type": None, "flag": False},
            {"name": "protection_info.policy_id", "value": None, "type": None, "flag": False},
            {"name": "tags.id", "value": None, "type": None, "flag": False},
            {"name": "is_deleted", "value": None, "type": None, "flag": False},
            {"name": "availability_zone", "value": None, "type": None, "flag": False}
        ]

        self.ec2_instance_dict = {}
        self.SetPagnation()
        #print(f"RestoreEC2 why apiDICT {apiDICT.get(self.id, {}).get('type', None)}")
        if apiDICT.get(self.id, {}).get('type', None):
            #print(f"apiDICT 01")
            if self.good:
                #print(f"apiDICT 02")
                if apiDICT.get(self.id, {}).get('type', None) == "get":
                    #print(f"apiDICT 03")
                    self.SetGET()
                elif apiDICT.get(self.id, {}).get('type', None) == "post":
                    #print(f"apiDICT 04")
                    self.SetPOST()
                else:
                    #print(f"apiDICT 05")
                    self.SetBad()

    def run(self):
        if self.Debug > 5: print("runAll: run api ")
        if self.search_filter_flag:

            if self.set_filters():
                pass
            else:
                if self.Debug > 1: print("runAll: run_all failed to set filters ")
                return False
        self.Results = []
        FirstResults = self.ExecAPI()
        if self.good:
            items = FirstResults.get("_embedded", {}).get("items", {})
            for i in items:
                check = self.pass_check(i)
                if check:
                    self.ec2_instance_dict[check] = i
        else:
            return False
        if self.total_pages_count:
            if self.total_pages_count > 1:
                for i in range(2, self.total_pages_count):
                    self.SetPageStart(i)
                    NextResults = self.ExecAPI()
                    if self.good:
                        items = NextResults.get("_embedded", {}).get("items", {})
                        for i in items:
                            check = self.pass_check(i)
                            if check:
                                self.ec2_instance_dict[check] = i
                    else:
                        return False
        return len(self.ec2_instance_dict)

    def pass_check(self, response):

        if self.AWSTagFlag:
            tags = response.get("tags", None)
            FoundTag = False
            for tag in tags:
                if self.AWSTagValue:
                    if tag.get("key", None) == self.AWSTagKey and tag.get("value", None) == self.AWSTagValue:
                        FoundTag = True
                else:  # Only tag key set not tag value
                    if tag.get("key", None) == self.AWSTagKey:
                        FoundTag = True
            if not FoundTag:
                if self.Debug > 5: print(f"pass_check: search tag set {self.AWSTagKey} {self.AWSTagValue} but no match in {tags}")
                return False
        if self.clumio_org_id_flag:
            if self.clumio_org_id == response.get("organizational_unit_id", None):
                pass
            else:
                #if self.Debug > 5: print(f"pass_check: search org id {self.clumio_org_id} does not match {response.get("organizational_unit_id", None)} ")
                return False
        if self.aws_vpc_id_flag:
            if self.aws_vpc_id == response.get("vpc_id", None):
                pass
            else:
                #if self.Debug > 5: print(f"pass_check: search vpc id {self.aws_vpc_id} does not match {response.get("vpc_id", None)} ")
                return False
        if self.aws_subnet_id_flag:
            if self.aws_subnet_id == response.get("subnet_id", None):
                pass
            else:
                #if self.Debug > 5: print(f"pass_check: search vpc id {self.aws_subnet_id} does not match {response.get("subnet_id", None)} ")
                return False
        clumio_instance_id = response.get("id", None)
        return clumio_instance_id

    def list_ec2_info(self, list_type):

        records = []
        if list_type == "ID":
            for inst in self.ec2_instance_dict.keys():
                rec = {"IDRecord": [self.ec2_instance_dict[inst].get("instance_native_id", None),inst]}
                records.append(rec)
            clumio_resource_list_dict = {"Records": records}
            if self.DumpToFileFlag:

                if not self.DataDump(clumio_resource_list_dict):
                    return False
            if self.Debug > 5: print(f"list_ec2_info: record type {list_type} record {clumio_resource_list_dict} ")
            return clumio_resource_list_dict
        elif list_type == "ALL":
            for inst in self.ec2_instance_dict.keys():
                rec = {"item": self.ec2_instance_dict[inst]}
                records.append(rec)
            clumio_resource_list_dict = {"Records": records}
            if self.DumpToFileFlag:

                if not self.DataDump(clumio_resource_list_dict):
                    return False
            if self.Debug > 5: print(f"list_ec2_info: record type {list_type} record {clumio_resource_list_dict} ")
            return clumio_resource_list_dict
        elif list_type == "BACKUP":

            for inst in self.ec2_instance_dict.keys():
                rec = {"instance_id": inst}
                records.append(rec)
            clumio_resource_list_dict = {"Records": records}
            if self.DumpToFileFlag:

                if not self.DataDump(clumio_resource_list_dict):
                    return False
            if self.Debug > 5: print(f"list_ec2_info: record type {list_type} record {clumio_resource_list_dict} ")
            return clumio_resource_list_dict
        if self.Debug > 5: print(f"list_ec2_info: unrecognized record type {list_type}")
        return {}

    def EC2SearchByTag(self, Key, Value):
        self.SetAWSTagKey(Key)
        self.SetAWSTagValue(Value)

    def SetPageSize(self, x):
        if self.queryParmsFlag:
            if "limit" in self.queryParms.keys():
                self.limit = x
                self.limit_expression_string = "limit=" + str(self.limit)
                self.limit_flag = True
                return self.build_url_suffix()
        self.SetBad()
        return None

    def SetPageStart(self, x):
        if self.queryParmsFlag:
            if "start" in self.queryParms.keys():
                self.start = x
                self.start_expression_string = "start=" + str(self.start)
                self.start_flag = True
                return self.build_url_suffix()
        self.SetBad()
        return None

    def build_url_suffix(self):
        self.url_suffix_list = []
        if self.good:
            if self.search_filter_flag:
                self.url_suffix_list.append(self.filter_expression_string_encoded)

            if self.limit_flag:
                self.url_suffix_list.append(self.limit_expression_string)

            if self.start_flag:
                self.url_suffix_list.append(self.startExpressionString)

            self.URLSuffString = "?" + "&".join(self.url_suffix_list)
            String = self.URLSuffString
            # #print(String)
            self.SetURL(String)
            return self.URLSuffString

    def set_filters(self):
        filterExpressionDict = {}
        filter_changed = False
        if self.queryParmsFlag:
            for filter_item in self.search_filters:
                if filter_item.get("flag",False):
                    if filter_item.get("name",None) in self.queryParms.get("filter", {}).keys():

                        if filter_item.get("type",None) in self.queryParms.get("filter", {}).get(filter_item.get("name",None), []):
                            # the $in type conditional value is expecting a list not a single value
                            if filter_item.get("type",None) == "$in":
                                self.filter_list.append([filter_item.get("name",None), filter_item.get("type",None), [filter_item.get("value",None)]])
                            else:
                                self.filter_list.append([filter_item.get("name", None), filter_item.get("type", None), filter_item.get("value", None)])
                            if self.Debug > 5: print(f"SetFilter: found new filter {filter_item}")
                            filter_changed = True
                        else:
                            if self.Debug > 2: print(f"SetFilter: Failure non valid filter condition {filter_item}")
                            return False
                    else:
                        if self.Debug > 2: print(f"SetFilter: Failure non valid filter name {filter_item}")
                        return False
                else:
                    if self.Debug > 5: print(f"SetFilter: Info filter value not set {filter_item}")
            if filter_changed:
                for i in self.filter_list:
                    filterExpressionDict[i[0]] = {i[1]: i[2]}
                    self.filter_expression_string = "filter=" + json.dumps(filterExpressionDict, separators=(',', ':'))
                    self.filter_expression_string_encoded = "filter=" + urllib.parse.quote(json.dumps(filterExpressionDict, separators=(',', ':')))
                    self.search_filter_flag = True
            if self.Debug > 5: print(f"SetFilter: filter dict unencoded {self.filter_expression_string} encoded {self.filter_expression_string_encoded}")
            return self.build_url_suffix()
        else:
            if self.Debug > 2: print("SetFilter: Failure API info incorrect")
            return False

    def find_environment_id(self):
        # if search for both an AWS account id and an AWS region is set find and use a Clumio environment id filter
        env_id_api  = EnvironmentId()
        env_id_api.SetToken(self.token)
        env_id_api.SetSearchAccountId(self.AWSAccountId)
        env_id_api.SetSearchRegion(self.AWSRegion)
        if env_id_api.runAll():
            rsp = env_id_api.EnvironmentIdParseResults()
            del env_id_api
            if rsp:
                self.clumio_environment_id = rsp
                self.clumio_environment_id_flag = True
                count = 0
                found = False
                for search_item in self.search_filters:
                    if search_item.get("name") == "environment_id":
                        self.search_filters[count] = {"name": "environment_id", "value": self.clumio_environment_id, "type": "$eq", "flag": True}
                        found = True
                    count += 1
                if not found:
                    if self.Debug > 2: print(f"find_environment_id: Failure to match search filter {rsp}")
                    return False
                return True
        return False
    def set_search_aws_account_id(self,value,condition="$eq"):
        #Set search for aws account
        if self.SetAWSAccountId(value):
            #if region flag is set then we can set, use environment id search
            if self.aws_region_flag:
                if self.find_environment_id():
                    pass
            self.search_filter_flag = True
            return True
        else:
            if self.Debug > 2: print(f"set_search_aws_account_id: Failure to set account id {value}")
            return False

    def set_search_aws_region(self,value,condition="$eq"):
        #Set search for aws region
        if self.SetAWSRegion(value):
            # if aws account id flag is set then we can set, use environment id search
            if self.aws_account_id_flag:
                if self.find_environment_id():
                    pass
            self.search_filter_flag = True
            return True
        else:
            if self.Debug > 2: print(f"set_search_aws_region: Failure to set aws region {value}")
            return False
    def set_search_compliance_status(self,value,condition="$eq"):
        # Set search filter for protection_status: allowed values are "compliant" and "non_compliant"
        valid_values = ["compliant","non_compliant"]
        if not value in valid_values:
            if self.Debug > 2: print(f"set_search_compliance_status: value not valid {value}")
            return False
        count = 0
        found = False
        for search_item in self.search_filters:
            if search_item.get("name") == "compliance_status":
                self.search_filters[count] = {"name": "compliance_status", "value": value, "type": "$eq", "flag": True}
                found = True
            count += 1
        # if not match to filter set was found - error
        if not found:
            if self.Debug > 2: print(f"set_search_compliance_status: Failure to match search filter {value}")
            return False
        self.search_filter_flag = True
        return True


    def set_search_protection_status(self,value,condition="$in"):
        # Set search filter for compliance status: allowed values are "protected", "unprotected", and "unsupported"
        valid_values = ["protected","unprotected","unsupported"]
        if not value in valid_values:
            if self.Debug > 2: print(f"set_search_protection_status: value not valid {value}")
            return False
        count = 0
        found = False
        for search_item in self.search_filters:
            if search_item.get("name") == "protection_status":
                self.search_filters[count] = {"name": "protection_status", "value": value, "type": "$in", "flag": True}
                found = True
            count += 1
        # if not match to filter set was found - error
        if not found:
            if self.Debug > 2: print(f"set_search_protection_status: Failure to match search filter {value}")
            return False
        self.search_filter_flag = True
        return True

    def set_search_protection_info_policy_id(self, value, condition="$eq"):
        # Set search filter for protection_info_policy_id: allowed values are clumio policy id
        # NOT IMPLEMENTED
        return False

    def set_search_tags_id(self, value, condition="$eq"):
        # Set search filter for tags.id: allowed values are clumio tag id
        # NOT IMPLEMENTED
        return False

    def set_search_is_deleted(self,value,condition="$eq"):
        #Set search filter for deleted instances: allowed values are true and false
        valid_values = ["true","false"]
        if not value in valid_values:
            if self.Debug > 2: print(f"set_search_is_deleted: value not valid {value}")
            return False
        count = 0
        found = False
        for search_item in self.search_filters:
            if search_item.get("name") == "is_deleted":
                self.search_filters[count] = {"name": "is_deleted", "value": value, "type": "$eq", "flag": True}
                found = True
            count += 1
        #if not match to filter set was found - error
        if not found:
            if self.Debug > 2: print(f"set_search_is_deleted: Failure to match search filter {value}")
            return False
        self.search_filter_flag = True
        return True

    def set_search_availability_zone(self,value,condition="$eq"):
        #Set search filter for AWS availability zone
        count = 0
        found = False
        for search_item in self.search_filters:
            if search_item.get("name") == "availability_zone":
                self.search_filters[count] = {"name": "availability_zone", "value": value, "type": "$eq", "flag": True}
                found = True
            count += 1
        #if not match to filter set was found - error
        if not found:
            if self.Debug > 2: print(f"set_search_availability_zone: Failure to match search filter {value}")
            return False
        # if aws account id flag is set then we can set, use environment id search
        self.search_filter_flag = True
        region = value.rstrip("abcdefg")
        if self.set_search_aws_region(region):
            return True
        else:
            if self.Debug > 2: print(f"set_search_availability_zone: Failure to set aws region {region}")
            return False


    def set_search_name(self,value,condition="$eq"):
        #Set search filter for instance name
        valid_conditions = ["$eq", "$contains"]
        if not value in valid_conditions:
            if self.Debug > 2: print(f"set_search_name: type not valid {condition}")
            return False
        count = 0
        found = False
        for search_item in self.search_filters:
            if search_item.get("name") == "name":
                self.search_filters[count] = {"name": "name", "value": value, "type": condition, "flag": True}
                found = True
            count += 1
        # if not match to filter set was found - error
        if not found:
            if self.Debug > 2: print(f"set_search_name: Failure to match search filter {value}")
            return False
        self.search_filter_flag = True
        return True

    def set_search_aws_tag(self,key,value=None):
        if self.Debug > 5: print(f"set_search_aws_tag: key {key}, and value {value}")
        if self.SetAWSTagKey(key) and self.SetAWSTagValue(value):
            return True
        else:
            return False

    def set_search_clumio_org_id(self,value):
        # NEED TO ADD CHECK FOR VALID ORG ID - Not implemented yet

        self.clumio_org_id = value
        self.clumio_org_id_flag = True
        return True

    def set_search_vpc_id(self,value):

        self.aws_vpc_id = value
        self.aws_vpc_id_flag = True
        return True

    def set_search_subnet_id(self,value):

        self.aws_subnet_id = value
        self.aws_subnet_id_flag = True
        return True

    def set_retention(self,units,value):
        valid_units = ["hours","days", "weeks", "months", "years"]
        if units not in valid_units:
            try:
                value = int(value)
            except ValueError:
                if self.Debug > 2: print(f"set_retention: value is not an integer {value}")
                return False
        self.retention_units = units
        self.retention_value = value
        self.retention_flag = True
        return True


class OnDemandBackupEC2(API):
    def __init__(self):
        super(OnDemandBackupEC2, self).__init__("007")
        self.backup_target_flag = False
        self.id = "007"
        self.log_activity_flag = False
        self.SetPOST()
        self.target_advanced_tier = None
        self.target_advanced_flag = False
        self.target_advanced_type = None
        self.target_retention_value = None
        self.target_retention_flag = False
        self.target_retention_units = None
        self.target_backup_type = None
        self.target_backup_type_flag = False
        self.target_region = None
        self.target_region_flag = False

        if apiDICT.get(self.id, {}).get('type', None):
            if self.good:
                if apiDICT.get(self.id, {}).get('type', None) == "get":
                    self.SetGET()
                elif apiDICT.get(self.id, {}).get('type', None) == "post":
                    self.SetPOST()
                else:
                    #print(f"apiDICT 05")
                    self.SetBad()

    def set_target_retention(self,units,value):
        valid_units = ['hours','day','week','month','year']
        if units not in valid_units:
            self.target_retention_units = units
            try:
                value = int(value)
            except ValueError:
                if self.Debug > 1: print(f"set_target_retention: invalid value {value}")
                return False
            self.target_retention_value = value
            self.target_retention_flag = True
            if self.Debug > 5: print(f"set_target_retention: set units {units} and value {value}")
            return True
        else:
            if self.Debug > 1: print(f"set_target_retention: invalid units {units}")
            return False

    def set_target_type(self,backup_type="clumio_backup"):
        valid_types = ["clumio_backup", "aws_snapshot"]
        if backup_type.lower() in valid_types:
            self.target_backup_type = backup_type.lower()
            self.target_backup_type_flag = True
        else:
            if self.Debug > 1: print(f"set_target_type: invalid type {backup_type}")
            return False

    def set_target_ec2_advanced_tier(self,tier):
        self.target_advanced_type = "aws_ec2_instance_backup"
        valid_tiers = ["standard", "lite"]
        if tier.lower() in valid_tiers:
            self.target_advanced_tier = tier.lower()
            self.target_advanced_flag = True
        else:
            if self.Debug > 1: print(f"set_target_ec2_advanced_tier: invalid tier {tier.lower()}")
            return False

    def set_target_region(self,region):
        if region in self.regionOption:
            self.target_region = region
            self.target_region_flag = True
            if self.Debug > 5: print(f"set_target_region: set region {region}")
            return True
        else:
            if self.Debug > 1: print(f"set_target_region: invalid region {region}")
            return False

    def ec2_backup_from_record(self,List):
        if self.Debug > 5: print(f"ec2_backup_from_record: number of records {len(List)}")
        if len(List) > 0:
            for record in List:
                if self.Debug > 6: print(f"ec2_backup_from_record: backup record: {record}")
                if self.run_backup_record(record):
                    pass
                else:
                    if self.Debug > 2: print(f"ec2_backup_from_record: failed api: {record}")
                    self.good = False
            return True
        else:
            if self.Debug > 2: print("ec2_backup_from_record: no records found")
            self.good = False
            return False

    def ec2_backup_from_file(self,filename, bucket, prefix, role, AWSSession, region):
        if self.SetupImportFileS3(filename, bucket, prefix, role, AWSSession, region="us-east-2"):
            if self.DataImport():
                #print(f"len of record {len(self.ImportData.get("Records",[]))}")
                for record in self.ImportData.get("Records",[]):
                    #print(f"record to restore: {record}")
                    runResults = self.runRestoreRecord(record)
                    #print(runResults)
                    #print(f"restore results for {record.get("instanceId",None)} {runResults}")
                    if self.log_activity_flag:
                        pass
                return True
        self.good = False
        return False

    def set_payload(self, record):
        instance_id = record.get("instance_id",None)
        if instance_id:
            setting_dict = {}
            if self.target_retention_flag:
                setting_dict["retention_duration"] = {"unit": self.target_retention_units,"value": self.target_retention_value}
            else:
                self.good = False
                if self.Debug > 1: print("set_payload: retention not set")
                return False
            if self.target_advanced_flag:
                setting_dict["advanced_settings"] = { self.target_advanced_type: { "backup_tier": self.target_advanced_tier } }
            if self.target_region_flag:
                setting_dict["backup_aws_region"] = self.target_region

            payload = {
                "settings": setting_dict,
                "instance_id": instance_id,
            }
            if self.target_backup_type_flag:
                payload["type"] = self.target_backup_type
            self.payload = payload
            self.payloadFlag = True
            if self.Debug > 6: print(f"set_payload: payload: {self.payload}")
            return True

        else:
            self.good = False
            if self.Debug > 2: print(f"set_payload: no instance id {record}")
            return False

    def run_backup_record(self, record):
        if self.good:
            if self.set_payload(record):
                result = self.ExecAPI()

                return result
        else:
            return False