from ClumioAPISDK import RestoreEC2, EC2BackupList, ListEC2Instance, OnDemandBackupEC2
import requests
import json
import logging
import boto3
from datetime import datetime, timedelta, timezone
import sys
import csv
import time
import io
import re
from botocore.exceptions import ClientError
import urllib.parse

# Copyright 2024, Clumio Inc.


# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at


#    http://www.apache.org/licenses/LICENSE-2.0


# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


test2 = ListEC2Instance()


Bear = "eyJhbGciOiJSUzI1NiIsImtpZCI6IlltWXdOamxrTnpndE5UZzVPQzAwWkRjMExXRXdPR1F0T1dZNU5XTmlNVGMwT0RkbSIsInR5cCI6IkpXVCJ9.eyJjdXN0b206bmFtZSI6Im1pa2U1IiwiY3VzdG9tOm5zIjoicHJvZC0wMS11dy0yIiwiY3VzdG9tOm9yZ2lkIjoiNTI5IiwiY3VzdG9tOnVzZXJpZCI6IjQxODc4IiwiaWF0IjoxNzE1MjU2NjM2LCJpc3MiOiJodHRwczovL3Byb2QtMDEtdXctMi1iYWNrZW5kLmFwaS5wcm9kLWNsdW1pby5jb20vYXBpL3Rva2Vucy9vcmdhbml6YXRpb25zLzUyOSIsImp0aSI6ImJmMDY5ZDc4LTU4OTgtNGQ3NC1hMDhkLTlmOTVjYjE3NDg3ZiIsInN1YiI6Ii90b2tlbnMvYmYwNjlkNzgtNTg5OC00ZDc0LWEwOGQtOWY5NWNiMTc0ODdmIiwidG9rZW5fdXNlIjoiYWNjZXNzIn0.TeWaa32dz2AxdJ5GoQ6dTlAWGpYynAX05B__XwOti-R-QApwb1lwBEn2M7yHSpU4Vub0rgbWSRs9w215Swf4RxUMnZlJge38m9cfgREzJpnbyj80PLXeVOC7JOVvA8FDq-98hxGE_nBxU8rhqvjZNOaH6nKuOmAaTdy_YWw5sDKf9gq9JF9xYt1OX-BxOdo5vH1J1McPYxBHtNuqyQbluIHbo_A2DWs7QGFdV7COweJHL3WMpuGOKNFdnTZ0j-2uf3rwcwzS6SrgTUDZKvIfP_s3-OfDOvnLD9wWWr42plGchhgqQh-D7OD96NYETA2pw8bJvb8qujz2Cdu13cynEw"





# SET Pagination and Token for EC2 Search
test2.SetToken(Bear)
test2.SetPageSize(100)
test2.SetDebug(2)
search_account = "908805993149"
search_region = "us-west-2"
search_tag_key = "Compliance"
search_tag_value = "Standard"
rsp_list_ec2 = {}
# Set search criteria
# region and aws account set - could set multiple other criteria e.g. set_search_tags_id or set_search_vpc_id
if test2.set_search_aws_region(search_region) and test2.set_search_aws_account_id(search_account) and test2.set_search_aws_tag(search_tag_key, search_tag_value):


   #RUN search across all discovered instances that match the search filter (using Pagination) note some search criteria is parsed after the data is collected
   rsp_code = test2.run()


   #Show results (this also parses based upon secondary criteria) by type: ID, ALL, BACKUP
   rsp_list_ec2 = test2.list_ec2_info("BACKUP")
   #If you want to see the search results
   list_as_string = json.dumps(rsp_list_ec2, indent=2)
   print(f"Search Results {list_as_string}")


test3 = OnDemandBackupEC2()
test3.SetToken(Bear)
test3.SetDebug(0)
test3.set_target_region("us-west-2")
test3.set_target_retention("days", 1)
test3.ec2_backup_from_record(rsp_list_ec2.get("Records", []))